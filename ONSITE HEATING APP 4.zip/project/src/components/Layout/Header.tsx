import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Thermometer, User, LogOut } from 'lucide-react';
import { User as UserType } from '../../types';

interface HeaderProps {
  user: UserType | null;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({ user, onLogout }) => {
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  if (!user) return null;

  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-8">
            <Link to="/dashboard" className="flex items-center space-x-2">
              <Thermometer className="h-8 w-8 text-orange-500" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">Onsite Heating</h1>
                <p className="text-xs text-gray-500">HVAC Solutions</p>
              </div>
            </Link>

            <nav className="hidden md:flex space-x-6">
              <Link
                to="/dashboard"
                className={`px-3 py-2 text-sm font-medium transition-colors ${
                  isActive('/dashboard')
                    ? 'text-orange-600 border-b-2 border-orange-600'
                    : 'text-gray-700 hover:text-orange-600'
                }`}
              >
                Dashboard
              </Link>
              <Link
                to="/jobs"
                className={`px-3 py-2 text-sm font-medium transition-colors ${
                  isActive('/jobs')
                    ? 'text-orange-600 border-b-2 border-orange-600'
                    : 'text-gray-700 hover:text-orange-600'
                }`}
              >
                {user.role === 'customer' ? 'My Services' : 'Jobs'}
              </Link>
              {user.role !== 'customer' && (
                <Link
                  to="/invoices"
                  className={`px-3 py-2 text-sm font-medium transition-colors ${
                    isActive('/invoices')
                      ? 'text-orange-600 border-b-2 border-orange-600'
                      : 'text-gray-700 hover:text-orange-600'
                  }`}
                >
                  Invoices
                </Link>
              )}
              {user.role === 'admin' && (
                <Link
                  to="/promotions"
                  className={`px-3 py-2 text-sm font-medium transition-colors ${
                    isActive('/promotions')
                      ? 'text-orange-600 border-b-2 border-orange-600'
                      : 'text-gray-700 hover:text-orange-600'
                  }`}
                >
                  Promotions
                </Link>
              )}
              {user.role !== 'customer' && (
                <Link
                  to="/technicians"
                  className={`px-3 py-2 text-sm font-medium transition-colors ${
                    isActive('/technicians')
                      ? 'text-orange-600 border-b-2 border-orange-600'
                      : 'text-gray-700 hover:text-orange-600'
                  }`}
                >
                  Technicians
                </Link>
              )}
              {user.role === 'customer' && (
                <Link
                  to="/payments"
                  className={`px-3 py-2 text-sm font-medium transition-colors ${
                    isActive('/payments')
                      ? 'text-orange-600 border-b-2 border-orange-600'
                      : 'text-gray-700 hover:text-orange-600'
                  }`}
                >
                  Payments
                </Link>
              )}
            </nav>
          </div>

          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <User className="h-5 w-5 text-gray-500" />
              <div className="text-sm">
                <p className="font-medium text-gray-900">{user.name}</p>
                <p className="text-gray-500 capitalize">{user.role}</p>
              </div>
            </div>
            <button
              onClick={onLogout}
              className="p-2 text-gray-500 hover:text-gray-700 transition-colors"
              title="Logout"
            >
              <LogOut className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};