import React, { useState } from 'react';
import { 
  User, 
  Phone, 
  Mail, 
  MapPin, 
  Star, 
  Wrench, 
  Clock,
  CheckCircle,
  AlertCircle,
  Plus,
  Edit
} from 'lucide-react';
import { Technician, User as UserType } from '../../types';
import { mockTechnicians, mockJobs } from '../../data/mockData';

interface TechnicianListProps {
  user: UserType;
}

export const TechnicianList: React.FC<TechnicianListProps> = ({ user }) => {
  const [technicians, setTechnicians] = useState(mockTechnicians);

  const getTechnicianJobs = (techId: string) => {
    return mockJobs.filter(job => job.technicianId === techId);
  };

  const getActiveJobs = (techId: string) => {
    return getTechnicianJobs(techId).filter(job => 
      job.status === 'in-progress' || job.status === 'assigned'
    ).length;
  };

  const toggleAvailability = (techId: string) => {
    setTechnicians(prev => prev.map(tech => 
      tech.id === techId ? { ...tech, isAvailable: !tech.isAvailable } : tech
    ));
    const tech = technicians.find(t => t.id === techId);
    alert(`${tech?.name} is now ${tech?.isAvailable ? 'busy' : 'available'}`);
  };

  const assignJob = (techId: string) => {
    const tech = technicians.find(t => t.id === techId);
    alert(`Job assignment interface would open for ${tech?.name}`);
  };

  const sendMessage = (techId: string) => {
    const tech = technicians.find(t => t.id === techId);
    const message = prompt(`Send message to ${tech?.name}:`);
    if (message) {
      alert(`Message sent to ${tech?.name}: "${message}"`);
    }
  };

  const viewSchedule = (techId: string) => {
    const tech = technicians.find(t => t.id === techId);
    alert(`Schedule view would open for ${tech?.name}`);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Technician Management</h1>
            <p className="text-gray-600 mt-2">Manage your HVAC technician team and assignments</p>
          </div>
          {user.role === 'admin' && (
            <button className="flex items-center space-x-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors">
              <Plus className="h-5 w-5" />
              <span>Add Technician</span>
            </button>
          )}
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Technicians</p>
              <p className="text-2xl font-bold text-gray-900 mt-2">{technicians.length}</p>
            </div>
            <User className="h-8 w-8 text-blue-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Available Now</p>
              <p className="text-2xl font-bold text-green-600 mt-2">
                {technicians.filter(t => t.isAvailable).length}
              </p>
            </div>
            <CheckCircle className="h-8 w-8 text-green-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Average Rating</p>
              <p className="text-2xl font-bold text-yellow-600 mt-2">
                {(technicians.reduce((sum, t) => sum + t.rating, 0) / technicians.length).toFixed(1)}
              </p>
            </div>
            <Star className="h-8 w-8 text-yellow-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Active Jobs</p>
              <p className="text-2xl font-bold text-orange-600 mt-2">
                {technicians.reduce((sum, tech) => sum + getActiveJobs(tech.id), 0)}
              </p>
            </div>
            <Wrench className="h-8 w-8 text-orange-500" />
          </div>
        </div>
      </div>

      {/* Technician Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {technicians.map((technician) => {
          const activeJobs = getActiveJobs(technician.id);
          const techJobs = getTechnicianJobs(technician.id);
          
          return (
            <div key={technician.id} className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-4">
                    <div className="relative">
                      <div className="w-16 h-16 bg-gradient-to-br from-orange-400 to-orange-600 rounded-full flex items-center justify-center">
                        <User className="h-8 w-8 text-white" />
                      </div>
                      <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full border-2 border-white ${
                        technician.isAvailable ? 'bg-green-500' : 'bg-red-500'
                      }`}></div>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900">{technician.name}</h3>
                      <div className="flex items-center space-x-1 mt-1">
                        <Star className="h-4 w-4 text-yellow-400 fill-current" />
                        <span className="text-sm font-medium text-gray-700">{technician.rating}</span>
                        <span className="text-sm text-gray-500">({technician.completedJobs} jobs)</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                      technician.isAvailable 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {technician.isAvailable ? 'Available' : 'Busy'}
                    </span>
                    {user.role === 'admin' && (
                      <button className="p-1 text-blue-600 hover:bg-blue-50 rounded transition-colors">
                        <Edit className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Contact Info */}
                <div className="space-y-2 mb-4">
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <Mail className="h-4 w-4" />
                    <span>{technician.email}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <Phone className="h-4 w-4" />
                    <span>{technician.phone}</span>
                  </div>
                  {technician.currentLocation && (
                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <MapPin className="h-4 w-4" />
                      <span>{technician.currentLocation.address}</span>
                    </div>
                  )}
                </div>

                {/* Specialties */}
                <div className="mb-4">
                  <p className="text-sm font-medium text-gray-700 mb-2">Specialties:</p>
                  <div className="flex flex-wrap gap-2">
                    {technician.specialties.map((specialty) => (
                      <span 
                        key={specialty}
                        className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full"
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Job Stats */}
                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-gray-900">{activeJobs}</p>
                    <p className="text-xs text-gray-600">Active Jobs</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-gray-900">{technician.completedJobs}</p>
                    <p className="text-xs text-gray-600">Completed</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-gray-900">{technician.rating}</p>
                    <p className="text-xs text-gray-600">Rating</p>
                  </div>
                </div>

                {/* Current Status */}
                <div className="bg-gray-50 rounded-lg p-3 mb-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      {technician.isAvailable ? (
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      ) : (
                        <AlertCircle className="h-4 w-4 text-orange-600" />
                      )}
                      <span className="text-sm font-medium text-gray-700">
                        {technician.isAvailable ? 'Ready for assignments' : `Working on ${activeJobs} job(s)`}
                      </span>
                    </div>
                    {user.role === 'admin' && (
                      <button
                        onClick={() => toggleAvailability(technician.id)}
                        className={`px-3 py-1 text-xs font-medium rounded-full transition-colors ${
                          technician.isAvailable
                            ? 'bg-red-100 text-red-800 hover:bg-red-200'
                            : 'bg-green-100 text-green-800 hover:bg-green-200'
                        }`}
                      >
                        {technician.isAvailable ? 'Set Busy' : 'Set Available'}
                      </button>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex justify-between items-center">
                  <button 
                    onClick={() => viewSchedule(technician.id)}
                    className="text-sm text-blue-600 hover:text-blue-800 font-medium"
                  >
                    View Schedule
                  </button>
                  <div className="space-x-2">
                    <button 
                      onClick={() => sendMessage(technician.id)}
                      className="px-3 py-1 text-sm text-gray-700 border border-gray-300 rounded hover:bg-gray-50 transition-colors"
                    >
                      Message
                    </button>
                    <button 
                      onClick={() => assignJob(technician.id)}
                      className="px-3 py-1 text-sm bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
                    >
                      Assign Job
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {technicians.length === 0 && (
        <div className="text-center py-12">
          <User className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No technicians found</h3>
          <p className="text-gray-500">Add your first technician to get started.</p>
        </div>
      )}
    </div>
  );
};