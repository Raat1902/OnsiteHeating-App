import React from 'react';
import { useState } from 'react';
import { CreditCard, Calendar, DollarSign, CheckCircle } from 'lucide-react';
import { User, Invoice, Payment } from '../../types';
import { mockInvoices, mockPayments } from '../../data/mockData';
import { format } from 'date-fns';

interface PaymentsListProps {
  user: User;
}

export const PaymentsList: React.FC<PaymentsListProps> = ({ user }) => {
  const [invoices, setInvoices] = useState(mockInvoices);
  const [payments, setPayments] = useState(mockPayments);
  const [processingPayment, setProcessingPayment] = useState<string | null>(null);

  // Customer view - show their invoices and payment status
  const customerInvoices = invoices.filter(invoice => invoice.customerId === '101');

  const handlePayNow = async (invoice: Invoice) => {
    setProcessingPayment(invoice.id);
    
    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Update invoice status to paid
    setInvoices(prev => prev.map(inv => 
      inv.id === invoice.id ? { ...inv, status: 'paid' } : inv
    ));
    
    // Add payment record
    const newPayment: Payment = {
      id: `PAY-${Date.now()}`,
      invoiceId: invoice.id,
      amount: invoice.amount,
      method: 'card',
      status: 'completed',
      processedAt: new Date().toISOString()
    };
    
    setPayments(prev => [...prev, newPayment]);
    setProcessingPayment(null);
    
    // Show success message
    alert(`Payment of $${invoice.amount} processed successfully!`);
  };

  const getPaymentForInvoice = (invoiceId: string) => {
    return payments.find(payment => payment.invoiceId === invoiceId);
  };
  
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Payments & Billing</h1>
        <p className="text-gray-600 mt-2">View your invoices and manage payments</p>
      </div>

      {/* Payment Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Outstanding</p>
              <p className="text-2xl font-bold text-orange-600 mt-2">
                ${customerInvoices.filter(inv => inv.status !== 'paid').reduce((sum, inv) => sum + inv.amount, 0).toLocaleString()}
              </p>
            </div>
            <DollarSign className="h-8 w-8 text-orange-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Paid This Year</p>
              <p className="text-2xl font-bold text-green-600 mt-2">
                ${customerInvoices.filter(inv => inv.status === 'paid').reduce((sum, inv) => sum + inv.amount, 0).toLocaleString()}
              </p>
            </div>
            <CheckCircle className="h-8 w-8 text-green-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Next Payment Due</p>
              <p className="text-2xl font-bold text-gray-900 mt-2">
                {customerInvoices.find(inv => inv.status === 'sent') ? 
                  format(new Date(customerInvoices.find(inv => inv.status === 'sent')!.dueDate), 'MMM dd') : 
                  'None'
                }
              </p>
            </div>
            <Calendar className="h-8 w-8 text-blue-500" />
          </div>
        </div>
      </div>

      {/* Outstanding Invoices */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-8">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Outstanding Invoices</h2>
        </div>
        <div className="p-6">
          {customerInvoices.filter(invoice => invoice.status !== 'paid').length === 0 ? (
            <div className="text-center py-8">
              <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">All caught up!</h3>
              <p className="text-gray-500">You don't have any outstanding invoices.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {customerInvoices.filter(invoice => invoice.status !== 'paid').map((invoice) => (
                <div key={invoice.id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="font-medium text-gray-900">Invoice {invoice.id}</h3>
                      <p className="text-sm text-gray-600">Job #{invoice.jobId}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-gray-900">${invoice.amount.toLocaleString()}</p>
                      <p className="text-sm text-gray-600">Due {format(new Date(invoice.dueDate), 'MMM dd, yyyy')}</p>
                    </div>
                  </div>
                  
                  <div className="space-y-2 mb-4">
                    {invoice.items.map((item) => (
                      <div key={item.id} className="flex justify-between text-sm">
                        <span className="text-gray-600">
                          {item.description} {item.quantity > 1 && `(${item.quantity}x)`}
                        </span>
                        <span className="font-medium">${item.amount.toLocaleString()}</span>
                      </div>
                    ))}
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      invoice.status === 'sent' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'
                    }`}>
                      {invoice.status.toUpperCase()}
                    </span>
                    <button 
                      onClick={() => handlePayNow(invoice)}
                      disabled={processingPayment === invoice.id}
                      className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {processingPayment === invoice.id ? 'Processing...' : 'Pay Now'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Payment History */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Payment History</h2>
        </div>
        <div className="p-6">
          {customerInvoices.filter(invoice => invoice.status === 'paid').length === 0 ? (
            <div className="text-center py-8">
              <CreditCard className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No payment history</h3>
              <p className="text-gray-500">Your payment history will appear here once you make payments.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {customerInvoices.filter(invoice => invoice.status === 'paid').map((invoice) => {
                const payment = getPaymentForInvoice(invoice.id);
                return (
                  <div key={invoice.id} className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="h-5 w-5 text-green-600" />
                      <div>
                        <p className="font-medium text-gray-900">Invoice {invoice.id}</p>
                        <p className="text-sm text-gray-600">
                          Paid via {payment?.method.replace('_', ' ') || 'card'} on{' '}
                          {payment ? format(new Date(payment.processedAt), 'MMM dd, yyyy') : 'N/A'}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-green-600">${invoice.amount.toLocaleString()}</p>
                      <p className="text-sm text-green-600">Paid</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};