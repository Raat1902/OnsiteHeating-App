import React, { useState } from 'react';
import { 
  Wrench, 
  Calendar, 
  Shield, 
  FileText, 
  AlertTriangle, 
  CheckCircle,
  Info,
  Download,
  Eye,
  Settings,
  Thermometer,
  Zap,
  Droplets
} from 'lucide-react';
import { Equipment, Customer } from '../../types';
import { format, differenceInDays } from 'date-fns';

interface EquipmentManagerProps {
  customer: Customer;
}

export const EquipmentManager: React.FC<EquipmentManagerProps> = ({ customer }) => {
  const [selectedEquipment, setSelectedEquipment] = useState<Equipment | null>(null);
  const [showSpecs, setShowSpecs] = useState(false);

  const getEquipmentIcon = (type: Equipment['type']) => {
    switch (type) {
      case 'furnace': return <Thermometer className="h-6 w-6" />;
      case 'ac_unit': return <Zap className="h-6 w-6" />;
      case 'water_heater': return <Droplets className="h-6 w-6" />;
      case 'heat_pump': return <Settings className="h-6 w-6" />;
      case 'ductwork': return <Wrench className="h-6 w-6" />;
      case 'thermostat': return <Settings className="h-6 w-6" />;
      default: return <Wrench className="h-6 w-6" />;
    }
  };

  const getStatusColor = (status: Equipment['status']) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'needs_service': return 'bg-yellow-100 text-yellow-800';
      case 'warranty_expired': return 'bg-orange-100 text-orange-800';
      case 'replaced': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getWarrantyStatus = (warrantyExpiry: string) => {
    const daysUntilExpiry = differenceInDays(new Date(warrantyExpiry), new Date());
    if (daysUntilExpiry < 0) return { status: 'expired', color: 'text-red-600', text: 'Expired' };
    if (daysUntilExpiry < 90) return { status: 'expiring', color: 'text-orange-600', text: `${daysUntilExpiry} days left` };
    return { status: 'active', color: 'text-green-600', text: `${Math.round(daysUntilExpiry / 365)} years left` };
  };

  const scheduleService = (equipmentId: string) => {
    alert(`Service scheduling for equipment ${equipmentId} would open here. This would integrate with the booking system.`);
  };

  const downloadManual = (manual: string) => {
    alert(`Downloading manual: ${manual}`);
  };

  const viewSpecifications = (equipment: Equipment) => {
    setSelectedEquipment(equipment);
    setShowSpecs(true);
  };

  if (!customer.equipment || customer.equipment.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="text-center py-8">
          <Wrench className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Equipment Registered</h3>
          <p className="text-gray-500">Contact us to register your HVAC equipment for warranty tracking and maintenance scheduling.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">My Equipment</h2>
          <p className="text-gray-600">Manage your HVAC equipment, warranties, and maintenance schedules</p>
        </div>
        
        <div className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {customer.equipment.map((equipment) => {
              const warranty = getWarrantyStatus(equipment.warrantyExpiry);
              
              return (
                <div key={equipment.id} className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-orange-100 rounded-lg text-orange-600">
                        {getEquipmentIcon(equipment.type)}
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 capitalize">
                          {equipment.type.replace('_', ' ')}
                        </h3>
                        <p className="text-sm text-gray-600">{equipment.brand} {equipment.model}</p>
                      </div>
                    </div>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(equipment.status)}`}>
                      {equipment.status.replace('_', ' ').toUpperCase()}
                    </span>
                  </div>

                  <div className="space-y-3 mb-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Serial Number:</span>
                      <span className="font-medium">{equipment.serialNumber}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Installed:</span>
                      <span className="font-medium">{format(new Date(equipment.installDate), 'MMM dd, yyyy')}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Warranty:</span>
                      <span className={`font-medium ${warranty.color}`}>
                        {warranty.text}
                      </span>
                    </div>
                    {equipment.nextServiceDue && (
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Next Service:</span>
                        <span className="font-medium">{format(new Date(equipment.nextServiceDue), 'MMM dd, yyyy')}</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <button 
                        onClick={() => viewSpecifications(equipment)}
                        className="text-sm text-blue-600 hover:text-blue-800 font-medium"
                      >
                        Learn More
                      </button>
                      {equipment.manuals && equipment.manuals.length > 0 && (
                        <button 
                          onClick={() => downloadManual(equipment.manuals![0])}
                          className="text-sm text-gray-600 hover:text-gray-800"
                        >
                          Manual
                        </button>
                      )}
                    </div>
                    <button 
                      onClick={() => scheduleService(equipment.id)}
                      className="px-3 py-1 bg-orange-600 text-white text-sm rounded hover:bg-orange-700 transition-colors"
                    >
                      Schedule Service
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Equipment Specifications Modal */}
      {showSpecs && selectedEquipment && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-orange-100 rounded-lg text-orange-600">
                    {getEquipmentIcon(selectedEquipment.type)}
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-gray-900">
                      {selectedEquipment.brand} {selectedEquipment.model}
                    </h2>
                    <p className="text-gray-600 capitalize">{selectedEquipment.type.replace('_', ' ')} Specifications</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowSpecs(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ×
                </button>
              </div>
            </div>

            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div className="bg-gray-50 rounded-lg p-4">
                  <h3 className="font-semibold text-gray-900 mb-3">Equipment Details</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Model:</span>
                      <span className="font-medium">{selectedEquipment.model}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Serial Number:</span>
                      <span className="font-medium">{selectedEquipment.serialNumber}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Install Date:</span>
                      <span className="font-medium">{format(new Date(selectedEquipment.installDate), 'MMM dd, yyyy')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Warranty Expires:</span>
                      <span className="font-medium">{format(new Date(selectedEquipment.warrantyExpiry), 'MMM dd, yyyy')}</span>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 rounded-lg p-4">
                  <h3 className="font-semibold text-gray-900 mb-3">Service Information</h3>
                  <div className="space-y-2 text-sm">
                    {selectedEquipment.lastServiceDate && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Last Service:</span>
                        <span className="font-medium">{format(new Date(selectedEquipment.lastServiceDate), 'MMM dd, yyyy')}</span>
                      </div>
                    )}
                    {selectedEquipment.nextServiceDue && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Next Service Due:</span>
                        <span className="font-medium">{format(new Date(selectedEquipment.nextServiceDue), 'MMM dd, yyyy')}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-gray-600">Status:</span>
                      <span className={`font-medium capitalize ${getStatusColor(selectedEquipment.status).includes('green') ? 'text-green-600' : 'text-orange-600'}`}>
                        {selectedEquipment.status.replace('_', ' ')}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                {['efficiency', 'capacity', 'performance', 'dimensions', 'electrical'].map(category => {
                  const specs = selectedEquipment.specifications.filter(spec => spec.category === category);
                  if (specs.length === 0) return null;

                  return (
                    <div key={category} className="border border-gray-200 rounded-lg p-4">
                      <h3 className="font-semibold text-gray-900 mb-3 capitalize">{category} Specifications</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {specs.map((spec, index) => (
                          <div key={index} className="flex justify-between">
                            <span className="text-gray-600">{spec.name}:</span>
                            <span className="font-medium">
                              {spec.value} {spec.unit && <span className="text-gray-500">{spec.unit}</span>}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>

              {selectedEquipment.manuals && selectedEquipment.manuals.length > 0 && (
                <div className="mt-6 border-t border-gray-200 pt-6">
                  <h3 className="font-semibold text-gray-900 mb-3">Documentation</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedEquipment.manuals.map((manual, index) => (
                      <button
                        key={index}
                        onClick={() => downloadManual(manual)}
                        className="flex items-center space-x-2 px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
                      >
                        <Download className="h-4 w-4" />
                        <span className="text-sm">{manual}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-end space-x-4 mt-6 pt-6 border-t border-gray-200">
                <button
                  onClick={() => setShowSpecs(false)}
                  className="px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Close
                </button>
                <button
                  onClick={() => scheduleService(selectedEquipment.id)}
                  className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700"
                >
                  Schedule Service
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};