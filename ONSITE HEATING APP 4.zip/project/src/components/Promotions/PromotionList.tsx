import React, { useState } from 'react';
import { 
  Tag, 
  Calendar, 
  Percent, 
  DollarSign, 
  Plus, 
  Edit, 
  Trash2, 
  Eye,
  ToggleLeft,
  ToggleRight
} from 'lucide-react';
import { Promotion, User } from '../../types';
import { mockPromotions } from '../../data/mockData';
import { format } from 'date-fns';

interface PromotionListProps {
  user: User;
}

export const PromotionList: React.FC<PromotionListProps> = ({ user }) => {
  const [promotions, setPromotions] = useState(mockPromotions);
  const [showForm, setShowForm] = useState(false);
  const [showAnalytics, setShowAnalytics] = useState<string | null>(null);

  const togglePromotion = (id: string) => {
    setPromotions(prev => prev.map(promo => 
      promo.id === id ? { ...promo, isActive: !promo.isActive } : promo
    ));
    const promo = promotions.find(p => p.id === id);
    alert(`Promotion "${promo?.title}" ${promo?.isActive ? 'deactivated' : 'activated'} successfully!`);
  };

  const deletePromotion = (id: string) => {
    if (window.confirm('Are you sure you want to delete this promotion?')) {
      setPromotions(prev => prev.filter(promo => promo.id !== id));
      alert('Promotion deleted successfully!');
    }
  };

  const showPromotionAnalytics = (promoId: string) => {
    const promo = promotions.find(p => p.id === promoId);
    if (promo) {
      const conversionRate = promo.maxUses ? (promo.currentUses / promo.maxUses * 100).toFixed(1) : 'N/A';
      const estimatedRevenue = promo.currentUses * 200; // Assuming average job value
      
      alert(`Analytics for "${promo.title}":
      
• Total Uses: ${promo.currentUses}
• Conversion Rate: ${conversionRate}%
• Estimated Revenue Impact: $${estimatedRevenue.toLocaleString()}
• Days Remaining: ${Math.ceil((new Date(promo.validTo).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))}
• Status: ${promo.isActive ? 'Active' : 'Inactive'}`);
    }
  };

  const getDiscountDisplay = (promo: Promotion) => {
    return promo.discountType === 'percentage' 
      ? `${promo.discountValue}% OFF`
      : `$${promo.discountValue} OFF`;
  };

  const getUsagePercentage = (promo: Promotion) => {
    if (!promo.maxUses) return 0;
    return (promo.currentUses / promo.maxUses) * 100;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Promotions & Offers</h1>
            <p className="text-gray-600 mt-2">Manage promotional campaigns and special offers</p>
          </div>
          <button 
            onClick={() => setShowForm(true)}
            className="flex items-center space-x-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
          >
            <Plus className="h-5 w-5" />
            <span>New Promotion</span>
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Active Promotions</p>
              <p className="text-2xl font-bold text-gray-900 mt-2">
                {promotions.filter(p => p.isActive).length}
              </p>
            </div>
            <Tag className="h-8 w-8 text-green-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Uses</p>
              <p className="text-2xl font-bold text-gray-900 mt-2">
                {promotions.reduce((sum, p) => sum + p.currentUses, 0)}
              </p>
            </div>
            <Eye className="h-8 w-8 text-blue-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Avg. Discount</p>
              <p className="text-2xl font-bold text-gray-900 mt-2">
                {Math.round(promotions.reduce((sum, p) => sum + p.discountValue, 0) / promotions.length)}%
              </p>
            </div>
            <Percent className="h-8 w-8 text-purple-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Expiring Soon</p>
              <p className="text-2xl font-bold text-orange-600 mt-2">
                {promotions.filter(p => {
                  const daysUntilExpiry = Math.ceil((new Date(p.validTo).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
                  return daysUntilExpiry <= 7 && daysUntilExpiry > 0;
                }).length}
              </p>
            </div>
            <Calendar className="h-8 w-8 text-orange-500" />
          </div>
        </div>
      </div>

      {/* Promotions Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {promotions.map((promo) => {
          const daysUntilExpiry = Math.ceil((new Date(promo.validTo).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
          const isExpiringSoon = daysUntilExpiry <= 7 && daysUntilExpiry > 0;
          const isExpired = daysUntilExpiry <= 0;
          
          return (
            <div key={promo.id} className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className={`p-3 rounded-full ${
                      promo.discountType === 'percentage' ? 'bg-purple-100' : 'bg-green-100'
                    }`}>
                      {promo.discountType === 'percentage' ? (
                        <Percent className={`h-6 w-6 ${
                          promo.discountType === 'percentage' ? 'text-purple-600' : 'text-green-600'
                        }`} />
                      ) : (
                        <DollarSign className="h-6 w-6 text-green-600" />
                      )}
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">{promo.title}</h3>
                      <p className="text-sm text-gray-600">{promo.description}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => togglePromotion(promo.id)}
                      className={`p-1 rounded transition-colors ${
                        promo.isActive ? 'text-green-600 hover:bg-green-50' : 'text-gray-400 hover:bg-gray-50'
                      }`}
                      title={promo.isActive ? 'Deactivate' : 'Activate'}
                    >
                      {promo.isActive ? (
                        <ToggleRight className="h-6 w-6" />
                      ) : (
                        <ToggleLeft className="h-6 w-6" />
                      )}
                    </button>
                    <button className="p-1 text-blue-600 hover:bg-blue-50 rounded transition-colors">
                      <Edit className="h-4 w-4" />
                    </button>
                    <button 
                      onClick={() => deletePromotion(promo.id)}
                      className="p-1 text-red-600 hover:bg-red-50 rounded transition-colors"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>

                {/* Discount Badge */}
                <div className="flex items-center justify-between mb-4">
                  <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                    promo.discountType === 'percentage' 
                      ? 'bg-purple-100 text-purple-800' 
                      : 'bg-green-100 text-green-800'
                  }`}>
                    {getDiscountDisplay(promo)}
                  </div>
                  
                  <div className="flex items-center space-x-4 text-sm text-gray-600">
                    <span className="flex items-center space-x-1">
                      <Calendar className="h-4 w-4" />
                      <span>
                        {format(new Date(promo.validFrom), 'MMM dd')} - {format(new Date(promo.validTo), 'MMM dd')}
                      </span>
                    </span>
                  </div>
                </div>

                {/* Service Types */}
                <div className="mb-4">
                  <p className="text-sm font-medium text-gray-700 mb-2">Applicable Services:</p>
                  <div className="flex flex-wrap gap-2">
                    {promo.serviceTypes.map((service) => (
                      <span 
                        key={service}
                        className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full capitalize"
                      >
                        {service}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Usage Stats */}
                {promo.maxUses && (
                  <div className="mb-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-gray-700">Usage</span>
                      <span className="text-sm text-gray-600">
                        {promo.currentUses} / {promo.maxUses} uses
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${getUsagePercentage(promo)}%` }}
                      ></div>
                    </div>
                  </div>
                )}

                {/* Promo Code */}
                {promo.code && (
                  <div className="bg-gray-50 rounded-lg p-3 mb-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-gray-700">Promo Code:</span>
                      <code className="bg-white px-2 py-1 rounded border text-sm font-mono">
                        {promo.code}
                      </code>
                    </div>
                  </div>
                )}

                {/* Status Indicators */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                      promo.isActive && !isExpired
                        ? 'bg-green-100 text-green-800'
                        : isExpired
                        ? 'bg-red-100 text-red-800'
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      {isExpired ? 'Expired' : promo.isActive ? 'Active' : 'Inactive'}
                    </span>
                    
                    {isExpiringSoon && (
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                        Expires in {daysUntilExpiry} days
                      </span>
                    )}
                  </div>
                  
                  <button className="text-sm text-blue-600 hover:text-blue-800 font-medium">
                  <button 
                    onClick={() => showPromotionAnalytics(promo.id)}
                    className="text-sm text-blue-600 hover:text-blue-800 font-medium"
                  >
                    View Analytics
                  </button>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {promotions.length === 0 && (
        <div className="text-center py-12">
          <Tag className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No promotions yet</h3>
          <p className="text-gray-500">Create your first promotion to attract more customers.</p>
        </div>
      )}
    </div>
  );
};