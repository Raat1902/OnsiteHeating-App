import React, { useState, useEffect } from 'react';
import { 
  Thermometer, 
  Power, 
  Calendar, 
  MapPin, 
  Zap, 
  Bell,
  Settings,
  TrendingUp,
  Home,
  Smartphone
} from 'lucide-react';
import { ThermostatSettings, WeatherData, Zone } from '../../types';
import { mockThermostatData, mockWeatherData } from '../../data/mockData';

interface ThermostatControlProps {
  customerId: string;
}

export const ThermostatControl: React.FC<ThermostatControlProps> = ({ customerId }) => {
  const [thermostat, setThermostat] = useState<ThermostatSettings>(mockThermostatData);
  const [weather, setWeather] = useState<WeatherData>(mockWeatherData);
  const [selectedZone, setSelectedZone] = useState<string>('main');
  const [showSchedule, setShowSchedule] = useState(false);
  const [showAnalytics, setShowAnalytics] = useState(false);

  const zones: Zone[] = [
    {
      id: 'main',
      name: 'Living Room',
      currentTemp: 21.5,
      targetTemp: 22,
      humidity: 45,
      isActive: true,
      sensorId: 'sensor-1'
    },
    {
      id: 'bedroom',
      name: 'Master Bedroom',
      currentTemp: 20.8,
      targetTemp: 20,
      humidity: 42,
      isActive: true,
      sensorId: 'sensor-2'
    },
    {
      id: 'kitchen',
      name: 'Kitchen',
      currentTemp: 22.1,
      targetTemp: 21,
      humidity: 48,
      isActive: false,
      sensorId: 'sensor-3'
    }
  ];

  const adjustTemperature = (delta: number) => {
    setThermostat(prev => ({
      ...prev,
      targetTemp: Math.max(10, Math.min(30, prev.targetTemp + delta))
    }));
  };

  const toggleMode = (mode: ThermostatSettings['mode']) => {
    setThermostat(prev => ({ ...prev, mode }));
  };

  const toggleAwayMode = () => {
    setThermostat(prev => ({ 
      ...prev, 
      awayMode: !prev.awayMode,
      targetTemp: !prev.awayMode ? 16 : 22 // Eco setback
    }));
  };

  const toggleGeofencing = () => {
    setThermostat(prev => ({ ...prev, geofencing: !prev.geofencing }));
    if (!thermostat.geofencing) {
      // Simulate geolocation request
      navigator.geolocation?.getCurrentPosition(
        (position) => {
          console.log('Geofencing enabled:', position.coords);
          alert('Geofencing enabled! Your thermostat will adjust when you leave/return home.');
        },
        (error) => {
          console.error('Geolocation error:', error);
          alert('Please enable location services for geofencing to work.');
        }
      );
    }
  };

  const currentZone = zones.find(z => z.id === selectedZone) || zones[0];
  const todayEnergyUse = thermostat.energyUsage.reduce((sum, data) => sum + data.energyUsed, 0);
  const todayEnergyCost = thermostat.energyUsage.reduce((sum, data) => sum + data.cost, 0);

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      {/* Header with Weather */}
      <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Smart Thermostat Control</h1>
            <p className="text-blue-100">Intelligent climate management for your home</p>
          </div>
          <div className="text-right">
            <div className="flex items-center space-x-2 mb-1">
              <Thermometer className="h-5 w-5" />
              <span className="text-xl font-bold">{weather.temperature}°C</span>
            </div>
            <p className="text-blue-100">{weather.condition}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Thermostat Control */}
        <div className="lg:col-span-2 bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Temperature Control</h2>
            <div className="flex items-center space-x-2">
              <select
                value={selectedZone}
                onChange={(e) => setSelectedZone(e.target.value)}
                className="px-3 py-1 border border-gray-300 rounded-lg text-sm"
              >
                {zones.map(zone => (
                  <option key={zone.id} value={zone.id}>{zone.name}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Temperature Display */}
          <div className="text-center mb-8">
            <div className="relative inline-block">
              <div className="w-48 h-48 rounded-full bg-gradient-to-br from-orange-400 to-red-500 flex items-center justify-center shadow-lg">
                <div className="text-center text-white">
                  <div className="text-4xl font-bold">{currentZone.currentTemp}°</div>
                  <div className="text-sm opacity-90">Current</div>
                </div>
              </div>
              <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 bg-white rounded-full px-4 py-2 shadow-lg border">
                <div className="text-center">
                  <div className="text-lg font-semibold text-gray-900">{thermostat.targetTemp}°</div>
                  <div className="text-xs text-gray-600">Target</div>
                </div>
              </div>
            </div>
          </div>

          {/* Temperature Controls */}
          <div className="flex items-center justify-center space-x-8 mb-6">
            <button
              onClick={() => adjustTemperature(-0.5)}
              className="w-12 h-12 rounded-full bg-blue-100 text-blue-600 hover:bg-blue-200 transition-colors flex items-center justify-center text-xl font-bold"
            >
              −
            </button>
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">{thermostat.targetTemp}°C</div>
              <div className="text-sm text-gray-600">Set Temperature</div>
            </div>
            <button
              onClick={() => adjustTemperature(0.5)}
              className="w-12 h-12 rounded-full bg-red-100 text-red-600 hover:bg-red-200 transition-colors flex items-center justify-center text-xl font-bold"
            >
              +
            </button>
          </div>

          {/* Mode Controls */}
          <div className="grid grid-cols-4 gap-2 mb-6">
            {(['heat', 'cool', 'auto', 'off'] as const).map((mode) => (
              <button
                key={mode}
                onClick={() => toggleMode(mode)}
                className={`py-2 px-4 rounded-lg text-sm font-medium transition-colors ${
                  thermostat.mode === mode
                    ? 'bg-orange-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {mode.charAt(0).toUpperCase() + mode.slice(1)}
              </button>
            ))}
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={toggleAwayMode}
              className={`flex items-center justify-center space-x-2 py-3 px-4 rounded-lg transition-colors ${
                thermostat.awayMode
                  ? 'bg-green-100 text-green-800'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <Home className="h-5 w-5" />
              <span>{thermostat.awayMode ? 'Home Mode' : 'Away Mode'}</span>
            </button>
            <button
              onClick={toggleGeofencing}
              className={`flex items-center justify-center space-x-2 py-3 px-4 rounded-lg transition-colors ${
                thermostat.geofencing
                  ? 'bg-blue-100 text-blue-800'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <Smartphone className="h-5 w-5" />
              <span>Geofencing {thermostat.geofencing ? 'On' : 'Off'}</span>
            </button>
          </div>
        </div>

        {/* Side Panel */}
        <div className="space-y-6">
          {/* Zone Status */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <h3 className="font-semibold text-gray-900 mb-4">Zone Status</h3>
            <div className="space-y-3">
              {zones.map((zone) => (
                <div key={zone.id} className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-900">{zone.name}</p>
                    <p className="text-xs text-gray-600">{zone.humidity}% humidity</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-gray-900">{zone.currentTemp}°C</p>
                    <p className="text-xs text-gray-600">Target: {zone.targetTemp}°C</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Energy Usage */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-900">Today's Usage</h3>
              <Zap className="h-5 w-5 text-yellow-500" />
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Energy Used:</span>
                <span className="text-sm font-medium">{todayEnergyUse.toFixed(1)} kWh</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Estimated Cost:</span>
                <span className="text-sm font-medium">${todayEnergyCost.toFixed(2)}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2 mt-3">
                <div 
                  className="bg-green-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(100, (todayEnergyUse / 10) * 100)}%` }}
                ></div>
              </div>
              <p className="text-xs text-gray-500 text-center">Daily target: 10 kWh</p>
            </div>
          </div>

          {/* Alerts */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-900">Alerts</h3>
              <Bell className="h-5 w-5 text-orange-500" />
            </div>
            <div className="space-y-2">
              {thermostat.alerts.filter(alert => !alert.isRead).map((alert) => (
                <div key={alert.id} className={`p-2 rounded-lg text-sm ${
                  alert.severity === 'critical' ? 'bg-red-50 text-red-800' :
                  alert.severity === 'high' ? 'bg-orange-50 text-orange-800' :
                  'bg-yellow-50 text-yellow-800'
                }`}>
                  {alert.message}
                </div>
              ))}
              {thermostat.alerts.filter(alert => !alert.isRead).length === 0 && (
                <p className="text-sm text-gray-500 text-center py-2">No active alerts</p>
              )}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <h3 className="font-semibold text-gray-900 mb-4">Quick Actions</h3>
            <div className="space-y-2">
              <button
                onClick={() => setShowSchedule(true)}
                className="w-full flex items-center space-x-2 py-2 px-3 text-left text-sm text-gray-700 hover:bg-gray-50 rounded-lg transition-colors"
              >
                <Calendar className="h-4 w-4" />
                <span>Edit Schedule</span>
              </button>
              <button
                onClick={() => setShowAnalytics(true)}
                className="w-full flex items-center space-x-2 py-2 px-3 text-left text-sm text-gray-700 hover:bg-gray-50 rounded-lg transition-colors"
              >
                <TrendingUp className="h-4 w-4" />
                <span>View Analytics</span>
              </button>
              <button className="w-full flex items-center space-x-2 py-2 px-3 text-left text-sm text-gray-700 hover:bg-gray-50 rounded-lg transition-colors">
                <Settings className="h-4 w-4" />
                <span>Advanced Settings</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Schedule Modal */}
      {showSchedule && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-bold text-gray-900">Weekly Schedule</h2>
            </div>
            <div className="p-6">
              <p className="text-gray-600 mb-4">Set different temperatures for different times of the day.</p>
              <div className="space-y-4">
                {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map((day, index) => (
                  <div key={day} className="border border-gray-200 rounded-lg p-4">
                    <h3 className="font-medium text-gray-900 mb-2">{day}</h3>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <label className="block text-gray-600 mb-1">Morning (6AM-9AM)</label>
                        <input type="number" defaultValue="22" className="w-full px-2 py-1 border rounded" />
                      </div>
                      <div>
                        <label className="block text-gray-600 mb-1">Day (9AM-5PM)</label>
                        <input type="number" defaultValue="20" className="w-full px-2 py-1 border rounded" />
                      </div>
                      <div>
                        <label className="block text-gray-600 mb-1">Evening (5PM-11PM)</label>
                        <input type="number" defaultValue="21" className="w-full px-2 py-1 border rounded" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex justify-end space-x-4 mt-6">
                <button
                  onClick={() => setShowSchedule(false)}
                  className="px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    setShowSchedule(false);
                    alert('Schedule saved successfully!');
                  }}
                  className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700"
                >
                  Save Schedule
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Analytics Modal */}
      {showAnalytics && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-bold text-gray-900">Energy Analytics</h2>
            </div>
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div className="bg-blue-50 rounded-lg p-4">
                  <h3 className="font-medium text-blue-900">This Week</h3>
                  <p className="text-2xl font-bold text-blue-600">45.2 kWh</p>
                  <p className="text-sm text-blue-700">$5.42 cost</p>
                </div>
                <div className="bg-green-50 rounded-lg p-4">
                  <h3 className="font-medium text-green-900">This Month</h3>
                  <p className="text-2xl font-bold text-green-600">180.5 kWh</p>
                  <p className="text-sm text-green-700">$21.66 cost</p>
                </div>
                <div className="bg-orange-50 rounded-lg p-4">
                  <h3 className="font-medium text-orange-900">Efficiency</h3>
                  <p className="text-2xl font-bold text-orange-600">92%</p>
                  <p className="text-sm text-orange-700">vs. last month</p>
                </div>
              </div>
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <h3 className="font-medium text-gray-900 mb-2">Temperature Trends</h3>
                <div className="h-32 bg-white rounded border flex items-center justify-center">
                  <p className="text-gray-500">Chart would display here with historical temperature data</p>
                </div>
              </div>
              <div className="flex justify-end">
                <button
                  onClick={() => setShowAnalytics(false)}
                  className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};