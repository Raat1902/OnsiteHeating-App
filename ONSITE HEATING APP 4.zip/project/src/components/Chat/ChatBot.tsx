import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Bot, User, Phone, Calendar, Wrench } from 'lucide-react';
import { ChatMessage, ChatAction } from '../../types';

interface ChatBotProps {
  onBookService?: () => void;
  onEmergencyCall?: () => void;
}

export const ChatBot: React.FC<ChatBotProps> = ({ onBookService, onEmergencyCall }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      message: "Hi! I'm your Onsite Heating assistant. How can I help you today?",
      sender: 'bot',
      timestamp: new Date().toISOString(),
      type: 'text',
      actions: [
        { id: 'book', label: 'Book Service', action: 'book_service' },
        { id: 'emergency', label: 'Emergency Help', action: 'emergency' },
        { id: 'status', label: 'Check Service Status', action: 'check_status' },
        { id: 'pricing', label: 'Get Pricing', action: 'pricing' }
      ]
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const getBotResponse = (userMessage: string): ChatMessage => {
    const message = userMessage.toLowerCase();
    
    if (message.includes('emergency') || message.includes('urgent') || message.includes('no heat')) {
      return {
        id: Date.now().toString(),
        message: "I understand this is urgent! For immediate emergency service, please call our 24/7 hotline. Our technicians are standing by.",
        sender: 'bot',
        timestamp: new Date().toISOString(),
        type: 'action',
        actions: [
          { id: 'call', label: 'Call Emergency Line', action: 'emergency_call' },
          { id: 'book_emergency', label: 'Book Emergency Service', action: 'book_emergency' }
        ]
      };
    }
    
    if (message.includes('book') || message.includes('schedule') || message.includes('appointment')) {
      return {
        id: Date.now().toString(),
        message: "I'd be happy to help you book a service! What type of service do you need?",
        sender: 'bot',
        timestamp: new Date().toISOString(),
        type: 'action',
        actions: [
          { id: 'heating', label: 'Heating Service', action: 'book_heating' },
          { id: 'cooling', label: 'Cooling Service', action: 'book_cooling' },
          { id: 'maintenance', label: 'Maintenance', action: 'book_maintenance' },
          { id: 'installation', label: 'Installation', action: 'book_installation' }
        ]
      };
    }
    
    if (message.includes('price') || message.includes('cost') || message.includes('pricing')) {
      return {
        id: Date.now().toString(),
        message: "Our pricing varies by service type. Here are our typical ranges:\n\n• Service Call: $89-$149\n• Furnace Repair: $150-$500\n• AC Repair: $150-$400\n• Installation: $2,500-$8,000\n\nWould you like a detailed quote?",
        sender: 'bot',
        timestamp: new Date().toISOString(),
        type: 'action',
        actions: [
          { id: 'quote', label: 'Get Free Quote', action: 'get_quote' },
          { id: 'book', label: 'Book Service', action: 'book_service' }
        ]
      };
    }
    
    if (message.includes('hours') || message.includes('open') || message.includes('available')) {
      return {
        id: Date.now().toString(),
        message: "Our business hours are:\n\n• Monday-Friday: 7 AM - 7 PM\n• Saturday: 8 AM - 5 PM\n• Sunday: Emergency only\n• Emergency Service: 24/7\n\nHow can I help you today?",
        sender: 'bot',
        timestamp: new Date().toISOString(),
        type: 'action',
        actions: [
          { id: 'book', label: 'Book Service', action: 'book_service' },
          { id: 'emergency', label: 'Emergency Service', action: 'emergency' }
        ]
      };
    }
    
    if (message.includes('thermostat') || message.includes('smart') || message.includes('control')) {
      return {
        id: Date.now().toString(),
        message: "We offer smart thermostat installation and setup! Our smart controls include:\n\n• WiFi-enabled thermostats\n• Mobile app control\n• Energy usage tracking\n• Scheduling and automation\n• Geofencing capabilities\n\nInterested in upgrading?",
        sender: 'bot',
        timestamp: new Date().toISOString(),
        type: 'action',
        actions: [
          { id: 'smart_quote', label: 'Get Smart Thermostat Quote', action: 'smart_quote' },
          { id: 'learn_more', label: 'Learn More', action: 'learn_smart' }
        ]
      };
    }
    
    // Default response
    return {
      id: Date.now().toString(),
      message: "I'm here to help with all your HVAC needs! I can assist you with booking services, emergency support, pricing information, and more. What would you like to know?",
      sender: 'bot',
      timestamp: new Date().toISOString(),
      type: 'action',
      actions: [
        { id: 'book', label: 'Book Service', action: 'book_service' },
        { id: 'emergency', label: 'Emergency Help', action: 'emergency' },
        { id: 'pricing', label: 'Get Pricing', action: 'pricing' },
        { id: 'hours', label: 'Business Hours', action: 'hours' }
      ]
    };
  };

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      message: inputMessage,
      sender: 'user',
      timestamp: new Date().toISOString(),
      type: 'text'
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);

    // Simulate bot typing delay
    setTimeout(() => {
      const botResponse = getBotResponse(inputMessage);
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1000);
  };

  const handleAction = (action: ChatAction) => {
    switch (action.action) {
      case 'book_service':
      case 'book_heating':
      case 'book_cooling':
      case 'book_maintenance':
      case 'book_installation':
      case 'book_emergency':
        onBookService?.();
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          message: "Perfect! I'm opening the booking form for you. You can select your service type and schedule an appointment.",
          sender: 'bot',
          timestamp: new Date().toISOString(),
          type: 'text'
        }]);
        break;
      case 'emergency':
      case 'emergency_call':
        onEmergencyCall?.();
        window.open('tel:+15551234567', '_self');
        break;
      case 'get_quote':
      case 'smart_quote':
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          message: "I'll connect you with our team for a personalized quote. Please book a consultation and we'll provide a detailed estimate.",
          sender: 'bot',
          timestamp: new Date().toISOString(),
          type: 'action',
          actions: [
            { id: 'book_consultation', label: 'Book Consultation', action: 'book_service' }
          ]
        }]);
        break;
      case 'check_status':
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          message: "To check your service status, please log into your account or provide your service request number. I can help you access your dashboard.",
          sender: 'bot',
          timestamp: new Date().toISOString(),
          type: 'text'
        }]);
        break;
      default:
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          message: "I'm processing your request. How else can I help you today?",
          sender: 'bot',
          timestamp: new Date().toISOString(),
          type: 'text'
        }]);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <>
      {/* Chat Toggle Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`fixed bottom-6 right-6 w-14 h-14 rounded-full shadow-lg transition-all duration-300 z-50 ${
          isOpen ? 'bg-red-500 hover:bg-red-600' : 'bg-orange-600 hover:bg-orange-700'
        } text-white flex items-center justify-center`}
      >
        {isOpen ? <X className="h-6 w-6" /> : <MessageCircle className="h-6 w-6" />}
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 w-96 h-[500px] bg-white rounded-lg shadow-2xl border border-gray-200 flex flex-col z-50">
          {/* Header */}
          <div className="bg-orange-600 text-white p-4 rounded-t-lg">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
                <Bot className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-semibold">Onsite Assistant</h3>
                <p className="text-xs text-orange-100">Online • Typically replies instantly</p>
              </div>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message) => (
              <div key={message.id} className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] ${message.sender === 'user' ? 'order-2' : 'order-1'}`}>
                  <div className={`flex items-start space-x-2 ${message.sender === 'user' ? 'flex-row-reverse space-x-reverse' : ''}`}>
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${
                      message.sender === 'user' ? 'bg-orange-600 text-white' : 'bg-gray-200 text-gray-600'
                    }`}>
                      {message.sender === 'user' ? <User className="h-3 w-3" /> : <Bot className="h-3 w-3" />}
                    </div>
                    <div className={`rounded-lg p-3 ${
                      message.sender === 'user' 
                        ? 'bg-orange-600 text-white' 
                        : 'bg-gray-100 text-gray-900'
                    }`}>
                      <p className="text-sm whitespace-pre-line">{message.message}</p>
                      {message.actions && (
                        <div className="mt-3 space-y-2">
                          {message.actions.map((action) => (
                            <button
                              key={action.id}
                              onClick={() => handleAction(action)}
                              className="block w-full text-left px-3 py-2 text-xs bg-white text-gray-700 rounded border hover:bg-gray-50 transition-colors"
                            >
                              {action.label}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex justify-start">
                <div className="flex items-start space-x-2">
                  <div className="w-6 h-6 bg-gray-200 rounded-full flex items-center justify-center">
                    <Bot className="h-3 w-3 text-gray-600" />
                  </div>
                  <div className="bg-gray-100 rounded-lg p-3">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-gray-200">
            <div className="flex space-x-2">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type your message..."
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 text-sm"
              />
              <button
                onClick={handleSendMessage}
                disabled={!inputMessage.trim()}
                className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <Send className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};