import React, { useState } from 'react';
import { X, Calendar, Clock, MapPin, DollarSign, Tag, CheckCircle } from 'lucide-react';
import { User, Promotion, Job } from '../../types';
import { format, addDays } from 'date-fns';

interface BookingModalProps {
  user: User;
  isOpen: boolean;
  onClose: () => void;
  selectedPromotion?: Promotion | null;
  onBookingComplete: (booking: Partial<Job>) => void;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  user,
  isOpen,
  onClose,
  selectedPromotion,
  onBookingComplete
}) => {
  const [step, setStep] = useState<'service' | 'details' | 'confirmation'>('service');
  const [bookingData, setBookingData] = useState({
    serviceType: 'repair' as Job['serviceType'],
    priority: 'medium' as Job['priority'],
    title: '',
    description: '',
    scheduledDate: '',
    address: user.address || '',
    phone: user.phone || '',
    estimatedCost: 0,
    appliedPromotion: selectedPromotion
  });

  const serviceTypes = [
    { value: 'installation', label: 'Installation', basePrice: 800, icon: '🔧' },
    { value: 'repair', label: 'Repair', basePrice: 200, icon: '🛠️' },
    { value: 'maintenance', label: 'Maintenance', basePrice: 150, icon: '⚙️' },
    { value: 'emergency', label: 'Emergency', basePrice: 300, icon: '🚨' }
  ];

  const calculateCost = () => {
    const basePrice = serviceTypes.find(s => s.value === bookingData.serviceType)?.basePrice || 200;
    let finalPrice = basePrice;

    if (selectedPromotion && selectedPromotion.serviceTypes.includes(bookingData.serviceType)) {
      if (selectedPromotion.discountType === 'percentage') {
        finalPrice = basePrice * (1 - selectedPromotion.discountValue / 100);
      } else {
        finalPrice = Math.max(0, basePrice - selectedPromotion.discountValue);
      }
    }

    return { basePrice, finalPrice, savings: basePrice - finalPrice };
  };

  const handleServiceSelect = (serviceType: Job['serviceType']) => {
    const service = serviceTypes.find(s => s.value === serviceType);
    setBookingData(prev => ({
      ...prev,
      serviceType,
      title: `${service?.label} Service`,
      estimatedCost: service?.basePrice || 200
    }));
  };

  const handleSubmit = () => {
    const { finalPrice } = calculateCost();
    const booking: Partial<Job> = {
      customerId: user.id,
      customerName: user.name,
      customerAddress: bookingData.address,
      customerPhone: bookingData.phone,
      title: bookingData.title,
      description: bookingData.description,
      serviceType: bookingData.serviceType,
      priority: bookingData.priority,
      status: 'pending',
      scheduledDate: new Date(bookingData.scheduledDate).toISOString(),
      estimatedDuration: 120,
      laborCost: finalPrice * 0.6,
      materialCost: finalPrice * 0.4,
      totalCost: finalPrice,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    onBookingComplete(booking);
    onClose();
    setStep('service');
  };

  if (!isOpen) return null;

  const { basePrice, finalPrice, savings } = calculateCost();

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900">
            {step === 'service' ? 'Select Service' : 
             step === 'details' ? 'Service Details' : 'Confirm Booking'}
          </h2>
          <button onClick={onClose} className="p-2 text-gray-400 hover:text-gray-600">
            <X className="h-6 w-6" />
          </button>
        </div>

        {step === 'service' && (
          <div className="p-6">
            {selectedPromotion && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
                <div className="flex items-center space-x-2 mb-2">
                  <Tag className="h-5 w-5 text-green-600" />
                  <span className="font-medium text-green-800">Promotion Applied!</span>
                </div>
                <p className="text-green-700">{selectedPromotion.title}</p>
                <p className="text-sm text-green-600">{selectedPromotion.description}</p>
              </div>
            )}

            <h3 className="text-lg font-semibold text-gray-900 mb-4">What service do you need?</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {serviceTypes.map((service) => {
                const isEligible = !selectedPromotion || selectedPromotion.serviceTypes.includes(service.value);
                return (
                  <button
                    key={service.value}
                    onClick={() => handleServiceSelect(service.value)}
                    disabled={!isEligible}
                    className={`p-6 border-2 rounded-lg text-left transition-all ${
                      bookingData.serviceType === service.value
                        ? 'border-orange-500 bg-orange-50'
                        : isEligible
                        ? 'border-gray-200 hover:border-orange-300 hover:bg-orange-25'
                        : 'border-gray-100 bg-gray-50 opacity-50 cursor-not-allowed'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-2xl">{service.icon}</span>
                      <span className="text-lg font-bold text-gray-900">
                        ${service.basePrice}
                      </span>
                    </div>
                    <h4 className="font-semibold text-gray-900">{service.label}</h4>
                    {!isEligible && (
                      <p className="text-xs text-gray-500 mt-1">Not eligible for selected promotion</p>
                    )}
                  </button>
                );
              })}
            </div>

            <div className="flex justify-end mt-6">
              <button
                onClick={() => setStep('details')}
                disabled={!bookingData.serviceType}
                className="px-6 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Continue
              </button>
            </div>
          </div>
        )}

        {step === 'details' && (
          <div className="p-6">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Service Description
                </label>
                <textarea
                  rows={3}
                  value={bookingData.description}
                  onChange={(e) => setBookingData(prev => ({ ...prev, description: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                  placeholder="Please describe the issue or service needed..."
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Preferred Date & Time
                  </label>
                  <input
                    type="datetime-local"
                    value={bookingData.scheduledDate}
                    min={format(addDays(new Date(), 1), "yyyy-MM-dd'T'HH:mm")}
                    onChange={(e) => setBookingData(prev => ({ ...prev, scheduledDate: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Priority Level
                  </label>
                  <select
                    value={bookingData.priority}
                    onChange={(e) => setBookingData(prev => ({ ...prev, priority: e.target.value as Job['priority'] }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                  >
                    <option value="low">Low - Within a week</option>
                    <option value="medium">Medium - Within 2-3 days</option>
                    <option value="high">High - Next day</option>
                    <option value="emergency">Emergency - ASAP</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Service Address
                </label>
                <textarea
                  rows={2}
                  value={bookingData.address}
                  onChange={(e) => setBookingData(prev => ({ ...prev, address: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                  placeholder="Enter the service address..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Contact Phone
                </label>
                <input
                  type="tel"
                  value={bookingData.phone}
                  onChange={(e) => setBookingData(prev => ({ ...prev, phone: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                  placeholder="(555) 123-4567"
                />
              </div>
            </div>

            <div className="flex justify-between mt-6">
              <button
                onClick={() => setStep('service')}
                className="px-6 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Back
              </button>
              <button
                onClick={() => setStep('confirmation')}
                disabled={!bookingData.description || !bookingData.scheduledDate || !bookingData.address}
                className="px-6 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Review Booking
              </button>
            </div>
          </div>
        )}

        {step === 'confirmation' && (
          <div className="p-6">
            <div className="bg-gray-50 rounded-lg p-6 mb-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Booking Summary</h3>
              
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Service:</span>
                  <span className="font-medium">{bookingData.title}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Date & Time:</span>
                  <span className="font-medium">
                    {format(new Date(bookingData.scheduledDate), 'EEEE, MMM dd, yyyy at h:mm a')}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Priority:</span>
                  <span className="font-medium capitalize">{bookingData.priority}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Address:</span>
                  <span className="font-medium text-right">{bookingData.address}</span>
                </div>
              </div>

              <div className="border-t border-gray-200 mt-4 pt-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Base Price:</span>
                  <span className={savings > 0 ? 'line-through text-gray-500' : 'font-bold text-gray-900'}>
                    ${basePrice}
                  </span>
                </div>
                
                {savings > 0 && (
                  <>
                    <div className="flex justify-between items-center text-green-600">
                      <span>Promotion Discount:</span>
                      <span>-${savings}</span>
                    </div>
                    <div className="flex justify-between items-center text-lg font-bold text-gray-900 mt-2">
                      <span>Final Price:</span>
                      <span>${finalPrice}</span>
                    </div>
                  </>
                )}
              </div>

              {selectedPromotion && (
                <div className="bg-green-100 rounded-lg p-3 mt-4">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm font-medium text-green-800">
                      {selectedPromotion.title} Applied!
                    </span>
                  </div>
                </div>
              )}
            </div>

            <div className="flex justify-between">
              <button
                onClick={() => setStep('details')}
                className="px-6 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Back
              </button>
              <button
                onClick={handleSubmit}
                className="px-8 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium"
              >
                Confirm Booking
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};