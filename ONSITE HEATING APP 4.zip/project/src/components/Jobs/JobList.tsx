import React, { useState } from 'react';
import { 
  Calendar, 
  MapPin, 
  Clock, 
  User, 
  Phone, 
  AlertTriangle, 
  CheckCircle,
  Filter,
  Search,
  Plus,
  Edit,
  Trash2,
  Eye
} from 'lucide-react';
import { Job, User as UserType } from '../../types';
import { mockJobs } from '../../data/mockData';
import { format } from 'date-fns';
import { JobForm } from './JobForm';

interface JobListProps {
  user: UserType;
}

export const JobList: React.FC<JobListProps> = ({ user }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [showJobForm, setShowJobForm] = useState(false);
  const [editingJob, setEditingJob] = useState<Job | undefined>();
  const [jobs, setJobs] = useState(mockJobs);

  const filteredJobs = mockJobs.filter(job => {
    const matchesSearch = job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         job.customerName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || job.status === statusFilter;
    const matchesPriority = priorityFilter === 'all' || job.priority === priorityFilter;
    
    // Customer only sees their own jobs
    if (user.role === 'customer') {
      return matchesSearch && matchesStatus && matchesPriority && job.customerId === '101';
    }
    
    // Technician only sees assigned jobs
    if (user.role === 'technician') {
      return matchesSearch && matchesStatus && matchesPriority && 
             (job.technicianId === '201' || job.technicianName);
    }
    
    return matchesSearch && matchesStatus && matchesPriority;
  });

  const getStatusColor = (status: Job['status']) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'in-progress': return 'bg-blue-100 text-blue-800';
      case 'assigned': return 'bg-yellow-100 text-yellow-800';
      case 'pending': return 'bg-orange-100 text-orange-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority: Job['priority']) => {
    switch (priority) {
      case 'emergency': return 'text-red-600 bg-red-100';
      case 'high': return 'text-orange-600 bg-orange-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'low': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const handleCreateJob = () => {
    setEditingJob(undefined);
    setShowJobForm(true);
  };

  const handleEditJob = (job: Job) => {
    setEditingJob(job);
    setShowJobForm(true);
  };

  const handleDeleteJob = (jobId: string) => {
    if (window.confirm('Are you sure you want to delete this job?')) {
      setJobs(prev => prev.filter(job => job.id !== jobId));
    }
  };

  const handleSaveJob = (jobData: Partial<Job>) => {
    if (editingJob) {
      // Update existing job
      setJobs(prev => prev.map(job => 
        job.id === editingJob.id ? { ...job, ...jobData } : job
      ));
      // Show success notification
      const notification = document.createElement('div');
      notification.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
      notification.textContent = 'Job updated successfully!';
      document.body.appendChild(notification);
      setTimeout(() => document.body.removeChild(notification), 3000);
    } else {
      // Create new job
      const newJob: Job = {
        id: `job-${Date.now()}`,
        ...jobData as Job
      };
      setJobs(prev => [newJob, ...prev]);
      // Show success notification
      const notification = document.createElement('div');
      notification.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
      notification.textContent = 'Job created successfully!';
      document.body.appendChild(notification);
      setTimeout(() => document.body.removeChild(notification), 3000);
    }
    setShowJobForm(false);
    setEditingJob(undefined);
  };

  const handleStatusUpdate = (jobId: string, newStatus: Job['status']) => {
    setJobs(prev => prev.map(job => 
      job.id === jobId ? { ...job, status: newStatus, updatedAt: new Date().toISOString() } : job
    ));
    // Show success notification
    const notification = document.createElement('div');
    notification.className = 'fixed top-4 right-4 bg-blue-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
    notification.textContent = `Job status updated to ${newStatus.replace('-', ' ')}`;
    document.body.appendChild(notification);
    setTimeout(() => document.body.removeChild(notification), 3000);
  };

  const handleViewAllJobs = () => {
    const totalJobs = mockJobs.length;
    const completedJobs = mockJobs.filter(job => job.status === 'completed').length;
    const pendingJobs = mockJobs.filter(job => job.status === 'pending').length;
    const inProgressJobs = mockJobs.filter(job => job.status === 'in-progress').length;
    
    alert(`Job Summary:
    
Total Jobs: ${totalJobs}
Completed: ${completedJobs}
In Progress: ${inProgressJobs}
Pending: ${pendingJobs}

Completion Rate: ${Math.round((completedJobs / totalJobs) * 100)}%
Active Jobs: ${inProgressJobs + pendingJobs}`);
  };

  const exportJobsToCSV = () => {
    const csvContent = [
      ['ID', 'Title', 'Customer', 'Status', 'Priority', 'Scheduled Date', 'Total Cost'].join(','),
      ...filteredJobs.map(job => [
        job.id,
        `"${job.title}"`,
        `"${job.customerName}"`,
        job.status,
        job.priority,
        new Date(job.scheduledDate).toLocaleDateString(),
        job.totalCost
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `jobs-export-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);

    // Show success notification
    const notification = document.createElement('div');
    notification.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
    notification.textContent = 'Jobs exported to CSV successfully!';
    document.body.appendChild(notification);
    setTimeout(() => document.body.removeChild(notification), 3000);
  };

  const printJobList = () => {
    const printContent = `
      <html>
        <head>
          <title>Job List - ${new Date().toLocaleDateString()}</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            .header { text-align: center; margin-bottom: 20px; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>Onsite Heating - Job List</h1>
            <p>Generated on ${new Date().toLocaleDateString()}</p>
          </div>
          <table>
            <thead>
              <tr>
                <th>Job ID</th>
                <th>Title</th>
                <th>Customer</th>
                <th>Status</th>
                <th>Priority</th>
                <th>Scheduled Date</th>
                <th>Total Cost</th>
              </tr>
            </thead>
            <tbody>
              ${filteredJobs.map(job => `
                <tr>
                  <td>${job.id}</td>
                  <td>${job.title}</td>
                  <td>${job.customerName}</td>
                  <td>${job.status}</td>
                  <td>${job.priority}</td>
                  <td>${new Date(job.scheduledDate).toLocaleDateString()}</td>
                  <td>$${job.totalCost.toLocaleString()}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">
          {user.role === 'customer' ? 'My Services' : 'Job Management'}
        </h1>
        <p className="text-gray-600 mt-2">
          {user.role === 'customer' 
            ? 'View and manage your HVAC service requests'
            : 'Manage and track all HVAC service jobs'
          }
        </p>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search jobs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
            />
          </div>
          
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
          >
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="assigned">Assigned</option>
            <option value="in-progress">In Progress</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
          </select>
          
          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
          >
            <option value="all">All Priority</option>
            <option value="emergency">Emergency</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
          
          <div className="flex space-x-2">
            {user.role !== 'customer' && (
              <button 
                onClick={handleCreateJob}
                className="flex items-center justify-center space-x-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
              >
                <Plus className="h-4 w-4" />
                <span>New Job</span>
              </button>
            )}
            <button 
              onClick={handleViewAllJobs}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              View All Jobs
            </button>
            {user.role !== 'customer' && (
              <>
                <button 
                  onClick={exportJobsToCSV}
                  className="flex items-center justify-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                >
                  <span>Export CSV</span>
                </button>
                <button 
                  onClick={printJobList}
                  className="flex items-center justify-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <span>Print List</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Job Cards */}
      <div className="space-y-6">
        {filteredJobs.map((job) => (
          <div key={job.id} className="bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-start space-x-4">
                  <div className={`p-3 rounded-full ${getPriorityColor(job.priority)}`}>
                    {job.priority === 'emergency' ? (
                      <AlertTriangle className="h-6 w-6" />
                    ) : job.status === 'completed' ? (
                      <CheckCircle className="h-6 w-6" />
                    ) : (
                      <Clock className="h-6 w-6" />
                    )}
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900">{job.title}</h3>
                    <p className="text-gray-600 mt-1">{job.description}</p>
                    <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
                      <span className="capitalize">{job.serviceType}</span>
                      <span>•</span>
                      <span className="capitalize">{job.priority} Priority</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <span className={`px-3 py-1 text-sm font-medium rounded-full ${getStatusColor(job.status)}`}>
                    {job.status.replace('-', ' ').toUpperCase()}
                  </span>
                  <span className="text-2xl font-bold text-gray-900">
                    ${job.totalCost.toLocaleString()}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <div className="flex items-center space-x-2 text-gray-600">
                  <User className="h-4 w-4" />
                  <div>
                    <p className="text-sm font-medium">{job.customerName}</p>
                    <p className="text-xs">Customer</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 text-gray-600">
                  <Phone className="h-4 w-4" />
                  <div>
                    <p className="text-sm font-medium">{job.customerPhone}</p>
                    <p className="text-xs">Phone</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 text-gray-600">
                  <Calendar className="h-4 w-4" />
                  <div>
                    <p className="text-sm font-medium">
                      {format(new Date(job.scheduledDate), 'MMM dd, yyyy')}
                    </p>
                    <p className="text-xs">
                      {format(new Date(job.scheduledDate), 'h:mm a')}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 text-gray-600">
                  <MapPin className="h-4 w-4" />
                  <div>
                    <p className="text-sm font-medium">{job.customerAddress.split(',')[0]}</p>
                    <p className="text-xs">{job.customerAddress.split(',').slice(1).join(',')}</p>
                  </div>
                </div>
              </div>

              {job.technicianName && (
                <div className="bg-gray-50 rounded-lg p-4 mb-4">
                  <div className="flex items-center space-x-2">
                    <User className="h-4 w-4 text-gray-600" />
                    <span className="text-sm font-medium text-gray-900">Assigned Technician:</span>
                    <span className="text-sm text-gray-600">{job.technicianName}</span>
                  </div>
                </div>
              )}

              {job.notes && (
                <div className="bg-blue-50 rounded-lg p-4 mb-4">
                  <p className="text-sm text-blue-800">{job.notes}</p>
                </div>
              )}

              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-500">
                  Created {format(new Date(job.createdAt), 'MMM dd, yyyy')} • 
                  Updated {format(new Date(job.updatedAt), 'MMM dd, yyyy')}
                </div>
                <div className="space-x-2">
                  <button className="px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                    Reschedule
                  </button>
                  {user.role !== 'customer' && (
                    <div className="flex space-x-2">
                      <button 
                        onClick={() => handleEditJob(job)}
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        title="Edit Job"
                      >
                        <Edit className="h-4 w-4" />
                      </button>
                      <button 
                        onClick={() => alert(`Job Details:\n\nTitle: ${job.title}\nCustomer: ${job.customerName}\nPhone: ${job.customerPhone}\nAddress: ${job.customerAddress}\nDescription: ${job.description}\nScheduled: ${format(new Date(job.scheduledDate), 'EEEE, MMM dd, yyyy at h:mm a')}\nTotal Cost: $${job.totalCost.toLocaleString()}\nNotes: ${job.notes || 'None'}`)}
                        className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                        title="View Details"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                      <button 
                        onClick={() => handleDeleteJob(job.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="Delete Job"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                      <button 
                        onClick={() => {
                          if (job.status === 'pending') {
                            handleStatusUpdate(job.id, 'assigned');
                          } else if (job.status === 'assigned') {
                            handleStatusUpdate(job.id, 'in-progress');
                          } else if (job.status === 'in-progress') {
                            handleStatusUpdate(job.id, 'completed');
                          }
                        }}
                        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                      >
                        {job.status === 'pending' ? 'Assign Technician' : 
                         job.status === 'assigned' ? 'Start Job' : 
                         job.status === 'in-progress' ? 'Complete Job' : 'View Details'}
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredJobs.length === 0 && (
        <div className="text-center py-12">
          <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No jobs found</h3>
          <p className="text-gray-500">Try adjusting your search criteria or create a new job.</p>
        </div>
      )}

      {/* Job Form Modal */}
      {showJobForm && (
        <JobForm
          user={user}
          job={editingJob}
          onSave={handleSaveJob}
          onCancel={() => {
            setShowJobForm(false);
            setEditingJob(undefined);
          }}
        />
      )}
    </div>
  );
};