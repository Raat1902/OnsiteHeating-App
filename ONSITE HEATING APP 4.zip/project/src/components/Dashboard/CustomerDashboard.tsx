import React from 'react';
import { useState } from 'react';
import { Calendar, Thermometer, DollarSign, Clock, Plus, X } from 'lucide-react';
import { User, Job } from '../../types';
import { mockJobs, mockInvoices, mockPromotions } from '../../data/mockData';
import { format } from 'date-fns';
import { BookingModal } from '../Booking/BookingModal';
import { EquipmentManager } from '../Equipment/EquipmentManager';

interface CustomerDashboardProps {
  user: User;
}

export const CustomerDashboard: React.FC<CustomerDashboardProps> = ({ user }) => {
  const [jobs, setJobs] = useState(mockJobs);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [selectedPromotion, setSelectedPromotion] = useState(null);
  const [redeemedPromotions, setRedeemedPromotions] = useState<string[]>([]);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);

  // Filter jobs for current customer (simulated)
  const myJobs = jobs.filter(job => job.customerId === '101');
  const myInvoices = mockInvoices.filter(invoice => invoice.customerId === '101');
  
  const nextService = myJobs.find(job => 
    job.status === 'assigned' || job.status === 'pending'
  );
  
  const activePromotions = mockPromotions.filter(promo => 
    promo.isActive && new Date(promo.validTo) > new Date()
  );

  const handleBookService = (promotion = null) => {
    setSelectedPromotion(promotion);
    setIsBookingModalOpen(true);
  };

  const handleBookingComplete = (booking: Partial<Job>) => {
    const newJob: Job = {
      id: `job-${Date.now()}`,
      ...booking as Job
    };
    
    setJobs(prev => [newJob, ...prev]);
    setIsBookingModalOpen(false);
    setSelectedPromotion(null);
    setShowSuccessMessage(true);
    
    setTimeout(() => setShowSuccessMessage(false), 5000);
  };

  const handlePayBalance = () => {
    const outstandingAmount = myInvoices.filter(inv => inv.status !== 'paid').reduce((sum, inv) => sum + inv.amount, 0);
    if (outstandingAmount > 0) {
      if (confirm(`Pay outstanding balance of $${outstandingAmount.toLocaleString()}?`)) {
        alert(`Payment of $${outstandingAmount.toLocaleString()} processed successfully! Thank you for your payment.`);
      }
    } else {
      alert('No outstanding balance. All invoices are paid!');
    }
  };

  const handleViewCalendar = () => {
    if (nextService) {
      alert(`Next Service Details:
      
Service: ${nextService.title}
Date: ${format(new Date(nextService.scheduledDate), 'EEEE, MMMM dd, yyyy')}
Time: ${format(new Date(nextService.scheduledDate), 'h:mm a')}
Technician: ${nextService.technicianName || 'To be assigned'}
Address: ${nextService.customerAddress}
Estimated Duration: ${Math.round(nextService.estimatedDuration / 60)}h ${nextService.estimatedDuration % 60}m
Total Cost: $${nextService.totalCost.toLocaleString()}

Would you like to add this to your calendar?`);
    } else {
      alert('No upcoming services scheduled. Would you like to book a service?');
    }
  };

  const redeemPromotion = (promoId: string) => {
    if (!redeemedPromotions.includes(promoId)) {
      setRedeemedPromotions(prev => [...prev, promoId]);
      const promotion = activePromotions.find(p => p.id === promoId);
      if (promotion) {
        handleBookService(promotion);
      }
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Welcome back, {user.name}</h1>
        <p className="text-gray-600 mt-2">Manage your HVAC services and appointments.</p>
      </div>

      {/* Success Message */}
      {showSuccessMessage && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
          <strong>Success!</strong> Your service has been booked. We'll contact you soon to confirm the appointment.
        </div>
      )}

      {/* Quick Actions */}
      <div className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-lg p-6 mb-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold mb-2">Need HVAC Service?</h2>
            <p className="text-orange-100">Schedule a service call or request emergency repairs</p>
          </div>
          <button 
            onClick={() => handleBookService()}
            className="bg-white text-orange-600 px-6 py-3 rounded-lg font-medium hover:bg-orange-50 transition-colors flex items-center space-x-2"
          >
            <Plus className="h-5 w-5" />
            <span>Book Service</span>
          </button>
        </div>
      </div>

      {/* Active Promotions */}
      {activePromotions.length > 0 && (
        <div className="bg-gradient-to-r from-green-500 to-blue-600 rounded-lg p-6 mb-8 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold mb-2">🎉 Special Offers Available!</h2>
              <p className="text-green-100 mb-4">Save money on your next HVAC service</p>
              <div className="space-y-2">
                {activePromotions.slice(0, 2).map(promo => (
                  <div key={promo.id} className="bg-white bg-opacity-20 rounded-lg p-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">{promo.title}</p>
                        <p className="text-sm text-green-100">{promo.description}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-lg">
                          {promo.discountType === 'percentage' ? `${promo.discountValue}% OFF` : `$${promo.discountValue} OFF`}
                        </p>
                        {promo.code && (
                          <p className="text-xs bg-white bg-opacity-30 px-2 py-1 rounded">
                            Code: {promo.code}
                          </p>
                        )}
                        <button 
                          onClick={() => redeemPromotion(promo.id)}
                          disabled={redeemedPromotions.includes(promo.id)}
                          className="mt-2 px-3 py-1 bg-white bg-opacity-30 text-white text-xs rounded hover:bg-opacity-40 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          {redeemedPromotions.includes(promo.id) ? 'Redeemed' : 'Redeem Now'}
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <button 
              onClick={() => handleBookService()}
              className="bg-white text-green-600 px-6 py-3 rounded-lg font-medium hover:bg-green-50 transition-colors"
            >
              View All Offers
            </button>
          </div>
        </div>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Services</p>
              <p className="text-2xl font-bold text-gray-900 mt-2">{myJobs.length}</p>
            </div>
            <Thermometer className="h-8 w-8 text-blue-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Outstanding Balance</p>
              <p className="text-2xl font-bold text-gray-900 mt-2">
                ${myInvoices.filter(inv => inv.status !== 'paid').reduce((sum, inv) => sum + inv.amount, 0).toLocaleString()}
              </p>
              {myInvoices.filter(inv => inv.status !== 'paid').length > 0 && (
                <button 
                  onClick={handlePayBalance}
                  className="mt-2 text-sm text-orange-600 hover:text-orange-800 font-medium"
                >
                  Pay Now
                </button>
              )}
            </div>
            <DollarSign className="h-8 w-8 text-green-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Next Service</p>
              <p className="text-2xl font-bold text-gray-900 mt-2">
                {nextService ? format(new Date(nextService.scheduledDate), 'MMM dd') : 'None'}
              </p>
              {nextService && (
                <button 
                  onClick={handleViewCalendar}
                  className="mt-2 text-sm text-orange-600 hover:text-orange-800 font-medium"
                >
                  View in Calendar
                </button>
              )}
            </div>
            <Calendar className="h-8 w-8 text-orange-500" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Equipment Management */}
        <div className="lg:col-span-2 mb-8">
          <EquipmentManager customer={{
            ...user,
            serviceHistory: myJobs.map(job => job.id),
            totalSpent: myInvoices.reduce((sum, inv) => sum + inv.amount, 0),
            loyaltyPoints: Math.floor(myInvoices.reduce((sum, inv) => sum + inv.amount, 0) / 10),
            equipment: [
              {
                id: 'eq-1',
                customerId: user.id,
                type: 'furnace',
                brand: 'Carrier',
                model: 'Performance 96 59TP6',
                serialNumber: 'CR2024001234',
                installDate: '2022-10-15T00:00:00Z',
                warrantyExpiry: '2032-10-15T00:00:00Z',
                lastServiceDate: '2024-09-15T00:00:00Z',
                nextServiceDue: '2025-09-15T00:00:00Z',
                status: 'active',
                specifications: [
                  { name: 'AFUE Rating', value: '96', unit: '%', category: 'efficiency' },
                  { name: 'BTU Input', value: '80,000', unit: 'BTU/h', category: 'capacity' },
                  { name: 'BTU Output', value: '76,800', unit: 'BTU/h', category: 'capacity' },
                  { name: 'Dimensions', value: '33" W x 29" D x 58" H', category: 'dimensions' },
                  { name: 'Weight', value: '180', unit: 'lbs', category: 'dimensions' },
                  { name: 'Electrical', value: '115V/60Hz/1Ph', category: 'electrical' },
                  { name: 'Gas Connection', value: '1/2" NPT', category: 'performance' }
                ],
                manuals: ['Carrier_59TP6_Installation_Manual.pdf', 'Carrier_59TP6_User_Guide.pdf']
              },
              {
                id: 'eq-2',
                customerId: user.id,
                type: 'ac_unit',
                brand: 'Carrier',
                model: 'Comfort 13 24ACC3',
                serialNumber: 'CR2023005678',
                installDate: '2023-05-20T00:00:00Z',
                warrantyExpiry: '2033-05-20T00:00:00Z',
                status: 'active',
                specifications: [
                  { name: 'SEER Rating', value: '13', category: 'efficiency' },
                  { name: 'Cooling Capacity', value: '24,000', unit: 'BTU/h', category: 'capacity' },
                  { name: 'Refrigerant Type', value: 'R-410A', category: 'performance' },
                  { name: 'Compressor Type', value: 'Single Stage', category: 'performance' },
                  { name: 'Sound Level', value: '76', unit: 'dB', category: 'performance' },
                  { name: 'Dimensions', value: '29" W x 29" D x 35" H', category: 'dimensions' },
                  { name: 'Weight', value: '125', unit: 'lbs', category: 'dimensions' }
                ]
              }
            ]
          }} />
        </div>

        {/* Upcoming Services */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Upcoming Services</h2>
          </div>
          <div className="p-6">
            {nextService ? (
              <div className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-medium text-gray-900">{nextService.title}</h3>
                    <p className="text-sm text-gray-600 mt-1">{nextService.description}</p>
                  </div>
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                    nextService.status === 'assigned' ? 'bg-green-100 text-green-800' :
                    'bg-yellow-100 text-yellow-800'
                  }`}>
                    {nextService.status}
                  </span>
                </div>
                
                <div className="flex items-center space-x-4 text-sm text-gray-600 mb-4">
                  <div className="flex items-center space-x-1">
                    <Calendar className="h-4 w-4" />
                    <span>{format(new Date(nextService.scheduledDate), 'EEEE, MMM dd, yyyy')}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="h-4 w-4" />
                    <span>{format(new Date(nextService.scheduledDate), 'h:mm a')}</span>
                  </div>
                </div>
                
                {nextService.technicianName && (
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-sm font-medium text-gray-900">Assigned Technician</p>
                    <p className="text-sm text-gray-600">{nextService.technicianName}</p>
                  </div>
                )}
                
                <div className="flex justify-between items-center mt-4">
                  <span className="text-lg font-bold text-gray-900">
                    ${nextService.totalCost.toLocaleString()}
                  </span>
                  <div className="space-x-2">
                    <button className="px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors text-sm">
                      Reschedule
                    </button>
                    <button 
                      onClick={() => alert('Job details would open here')}
                      className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
                    >
                      View Details
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">No upcoming services scheduled</p>
                <button 
                  onClick={() => handleBookService()}
                  className="mt-4 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
                >
                  Schedule Service
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Service History */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Recent Service History</h2>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {myJobs.filter(job => job.status === 'completed').slice(0, 3).map((job) => (
                <div key={job.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium text-gray-900">{job.title}</p>
                    <p className="text-sm text-gray-600">{format(new Date(job.scheduledDate), 'MMM dd, yyyy')}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-gray-900">${job.totalCost.toLocaleString()}</p>
                    <p className="text-sm text-green-600">Completed</p>
                  </div>
                </div>
              ))}
              
              {myJobs.filter(job => job.status === 'completed').length === 0 && (
                <div className="text-center py-8">
                  <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">No service history yet</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Booking Modal */}
      <BookingModal
        user={user}
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
        selectedPromotion={selectedPromotion}
        onBookingComplete={handleBookingComplete}
      />
    </div>
  );
};