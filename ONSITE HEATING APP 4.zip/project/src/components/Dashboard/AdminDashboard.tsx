import React from 'react';
import { useState } from 'react';
import { 
  Calendar, 
  Users, 
  Wrench, 
  DollarSign, 
  TrendingUp, 
  Clock,
  AlertTriangle,
  CheckCircle,
  Download,
  Printer,
  Plus,
  Eye,
  Edit,
  Trash2,
  FileText,
  BarChart3
} from 'lucide-react';
import { User, Job } from '../../types';
import { mockJobs, mockInvoices, mockTechnicians, mockPromotions } from '../../data/mockData';
import { format } from 'date-fns';
import { JobForm } from '../Jobs/JobForm';

interface AdminDashboardProps {
  user: User;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ user }) => {
  const [jobs, setJobs] = useState(mockJobs);
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [showJobForm, setShowJobForm] = useState(false);
  const [editingJob, setEditingJob] = useState<Job | undefined>();
  
  const totalJobs = jobs.length;
  const completedJobs = jobs.filter(job => job.status === 'completed').length;
  const pendingJobs = jobs.filter(job => job.status === 'pending').length;
  const inProgressJobs = jobs.filter(job => job.status === 'in-progress').length;
  
  const totalRevenue = mockInvoices.reduce((sum, invoice) => sum + invoice.amount, 0);
  const paidInvoices = mockInvoices.filter(invoice => invoice.status === 'paid');
  const paidRevenue = paidInvoices.reduce((sum, invoice) => sum + invoice.amount, 0);

  const stats = [
    {
      title: 'Total Jobs',
      value: totalJobs,
      icon: Wrench,
      color: 'bg-blue-500',
      change: '+12%'
    },
    {
      title: 'Active Technicians',
      value: mockTechnicians.filter(t => t.isAvailable).length,
      icon: Users,
      color: 'bg-green-500',
      change: '+1'
    },
    {
      title: 'Monthly Revenue',
      value: `$${totalRevenue.toLocaleString()}`,
      icon: DollarSign,
      color: 'bg-orange-500',
      change: '+8%'
    },
    {
      title: 'Completion Rate',
      value: `${Math.round((completedJobs / totalJobs) * 100)}%`,
      icon: TrendingUp,
      color: 'bg-purple-500',
      change: '+5%'
    }
  ];

  const exportAllData = () => {
    const csvContent = [
      ['Type', 'ID', 'Title/Name', 'Status', 'Date', 'Amount/Value'].join(','),
      ...jobs.map(job => [
        'Job',
        job.id,
        `"${job.title}"`,
        job.status,
        new Date(job.scheduledDate).toLocaleDateString(),
        job.totalCost
      ]),
      ...mockInvoices.map(invoice => [
        'Invoice',
        invoice.id,
        `"${invoice.customerName}"`,
        invoice.status,
        new Date(invoice.createdAt).toLocaleDateString(),
        invoice.amount
      ])
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `business-data-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);

    // Show success notification
    const notification = document.createElement('div');
    notification.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
    notification.textContent = 'Business data exported successfully!';
    document.body.appendChild(notification);
    setTimeout(() => document.body.removeChild(notification), 3000);
  };

  const generateBusinessReport = () => {
    const reportContent = `
      <html>
        <head>
          <title>Onsite Heating - Business Report</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #f97316; padding-bottom: 20px; }
            .section { margin-bottom: 30px; }
            .stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 30px; }
            .stat-card { border: 1px solid #ddd; padding: 15px; border-radius: 8px; text-align: center; }
            table { width: 100%; border-collapse: collapse; margin-top: 15px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            .summary { background-color: #f9f9f9; padding: 20px; border-radius: 8px; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>Onsite Heating - Business Report</h1>
            <p>Generated on ${new Date().toLocaleDateString()}</p>
            <p>Report Period: ${new Date().toLocaleDateString()} - Current</p>
          </div>
          
          <div class="stats">
            <div class="stat-card">
              <h3>Total Jobs</h3>
              <p style="font-size: 24px; font-weight: bold; color: #3b82f6;">${totalJobs}</p>
            </div>
            <div class="stat-card">
              <h3>Completed Jobs</h3>
              <p style="font-size: 24px; font-weight: bold; color: #10b981;">${completedJobs}</p>
            </div>
            <div class="stat-card">
              <h3>Total Revenue</h3>
              <p style="font-size: 24px; font-weight: bold; color: #f97316;">$${totalRevenue.toLocaleString()}</p>
            </div>
            <div class="stat-card">
              <h3>Completion Rate</h3>
              <p style="font-size: 24px; font-weight: bold; color: #8b5cf6;">${Math.round((completedJobs / totalJobs) * 100)}%</p>
            </div>
          </div>

          <div class="section">
            <h2>Recent Jobs</h2>
            <table>
              <thead>
                <tr>
                  <th>Job ID</th>
                  <th>Title</th>
                  <th>Customer</th>
                  <th>Status</th>
                  <th>Technician</th>
                  <th>Total Cost</th>
                </tr>
              </thead>
              <tbody>
                ${jobs.slice(0, 10).map(job => `
                  <tr>
                    <td>${job.id}</td>
                    <td>${job.title}</td>
                    <td>${job.customerName}</td>
                    <td>${job.status}</td>
                    <td>${job.technicianName || 'Unassigned'}</td>
                    <td>$${job.totalCost.toLocaleString()}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>

          <div class="section">
            <h2>Technician Performance</h2>
            <table>
              <thead>
                <tr>
                  <th>Technician</th>
                  <th>Completed Jobs</th>
                  <th>Rating</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                ${mockTechnicians.map(tech => `
                  <tr>
                    <td>${tech.name}</td>
                    <td>${tech.completedJobs}</td>
                    <td>${tech.rating}/5.0</td>
                    <td>${tech.isAvailable ? 'Available' : 'Busy'}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>

          <div class="summary">
            <h2>Executive Summary</h2>
            <ul>
              <li>Total active jobs: ${inProgressJobs + pendingJobs}</li>
              <li>Revenue collected: $${paidRevenue.toLocaleString()} (${Math.round((paidRevenue/totalRevenue)*100)}%)</li>
              <li>Average job value: $${Math.round(totalRevenue/totalJobs).toLocaleString()}</li>
              <li>Active promotions: ${mockPromotions.filter(p => p.isActive).length}</li>
              <li>Available technicians: ${mockTechnicians.filter(t => t.isAvailable).length}/${mockTechnicians.length}</li>
            </ul>
          </div>
        </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(reportContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const quickAssignJob = (jobId: string) => {
    const availableTechs = mockTechnicians.filter(t => t.isAvailable);
    if (availableTechs.length === 0) {
      alert('No technicians are currently available for assignment.');
      return;
    }

    const techNames = availableTechs.map(t => `${t.name} (${t.specialties.join(', ')})`).join('\n');
    const selectedTech = prompt(`Available Technicians:\n${techNames}\n\nEnter technician name to assign:`);
    
    if (selectedTech) {
      const tech = availableTechs.find(t => t.name.toLowerCase().includes(selectedTech.toLowerCase()));
      if (tech) {
        setJobs(prev => prev.map(job => 
          job.id === jobId ? { 
            ...job, 
            technicianId: tech.id, 
            technicianName: tech.name,
            status: 'assigned',
            updatedAt: new Date().toISOString()
          } : job
        ));
        
        // Show success notification
        const notification = document.createElement('div');
        notification.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
        notification.textContent = `Job assigned to ${tech.name} successfully!`;
        document.body.appendChild(notification);
        setTimeout(() => document.body.removeChild(notification), 3000);
      } else {
        alert('Technician not found. Please try again.');
      }
    }
  };

  const viewJobDetails = (jobId: string) => {
    const job = jobs.find(j => j.id === jobId);
    if (job) {
      setEditingJob(job);
      setShowJobForm(true);
    }
  };

  const handleQuickAction = (action: string) => {
    switch (action) {
      case 'new_job':
        setShowJobForm(true);
        setEditingJob(undefined);
        break;
      case 'new_invoice':
        const newInvoice = {
          id: `INV-${String(Date.now()).slice(-3)}`,
          jobId: 'new-job',
          customerId: '999',
          customerName: 'New Customer',
          amount: 0,
          status: 'draft' as const,
          dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          createdAt: new Date().toISOString(),
          items: []
        };
        alert(`New invoice ${newInvoice.id} created successfully!`);
        break;
      case 'manage_team':
        window.location.href = '/technicians';
        break;
      case 'view_reports':
        generateBusinessReport();
        break;
      default:
        break;
    }
  };
  const handleSaveJob = (jobData: Partial<Job>) => {
    if (editingJob) {
      setJobs(prev => prev.map(job => 
        job.id === editingJob.id ? { ...job, ...jobData } : job
      ));
      alert('Job updated successfully!');
    } else {
      const newJob: Job = {
        id: `job-${Date.now()}`,
        ...jobData as Job
      };
      setJobs(prev => [newJob, ...prev]);
      alert('Job created successfully!');
    }
    setShowJobForm(false);
    setEditingJob(undefined);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Welcome back, {user.name}</h1>
            <p className="text-gray-600 mt-2">Here's what's happening with your HVAC business today.</p>
          </div>
          <div className="flex items-center space-x-4">
            <button 
              onClick={() => setShowAnalytics(!showAnalytics)}
              className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
            >
              <BarChart3 className="h-4 w-4" />
              <span>Analytics</span>
            </button>
            <button 
              onClick={exportAllData}
              className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
            >
              <Download className="h-4 w-4" />
              <span>Export Data</span>
            </button>
            <button 
              onClick={generateBusinessReport}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Printer className="h-4 w-4" />
              <span>Generate Report</span>
            </button>
          </div>
        </div>
      </div>

      {/* Analytics Panel */}
      {showAnalytics && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Business Analytics</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-blue-50 rounded-lg p-4">
              <h3 className="font-medium text-blue-900 mb-2">Revenue Trends</h3>
              <p className="text-2xl font-bold text-blue-600">${totalRevenue.toLocaleString()}</p>
              <p className="text-sm text-blue-700">+15% from last month</p>
              <div className="mt-3 bg-blue-200 rounded-full h-2">
                <div className="bg-blue-600 h-2 rounded-full" style={{ width: '75%' }}></div>
              </div>
            </div>
            <div className="bg-green-50 rounded-lg p-4">
              <h3 className="font-medium text-green-900 mb-2">Job Completion</h3>
              <p className="text-2xl font-bold text-green-600">{Math.round((completedJobs / totalJobs) * 100)}%</p>
              <p className="text-sm text-green-700">+5% efficiency gain</p>
              <div className="mt-3 bg-green-200 rounded-full h-2">
                <div className="bg-green-600 h-2 rounded-full" style={{ width: `${(completedJobs / totalJobs) * 100}%` }}></div>
              </div>
            </div>
            <div className="bg-orange-50 rounded-lg p-4">
              <h3 className="font-medium text-orange-900 mb-2">Customer Satisfaction</h3>
              <p className="text-2xl font-bold text-orange-600">4.8/5.0</p>
              <p className="text-sm text-orange-700">Based on recent reviews</p>
              <div className="mt-3 bg-orange-200 rounded-full h-2">
                <div className="bg-orange-600 h-2 rounded-full" style={{ width: '96%' }}></div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                <p className="text-2xl font-bold text-gray-900 mt-2">{stat.value}</p>
                <p className="text-sm text-green-600 mt-1">{stat.change} from last month</p>
              </div>
              <div className={`${stat.color} p-3 rounded-lg`}>
                <stat.icon className="h-6 w-6 text-white" />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Jobs with Actions */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">Recent Jobs</h2>
              <button className="text-sm text-blue-600 hover:text-blue-800 font-medium">
                View All Jobs
              </button>
            </div>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {jobs.slice(0, 5).map((job) => (
                <div key={job.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-full ${
                        job.priority === 'emergency' ? 'bg-red-100' :
                        job.priority === 'high' ? 'bg-orange-100' :
                        job.priority === 'medium' ? 'bg-yellow-100' : 'bg-green-100'
                      }`}>
                        {job.status === 'completed' ? (
                          <CheckCircle className="h-4 w-4 text-green-600" />
                        ) : job.priority === 'emergency' ? (
                          <AlertTriangle className="h-4 w-4 text-red-600" />
                        ) : (
                          <Clock className={`h-4 w-4 ${
                            job.priority === 'high' ? 'text-orange-600' :
                            job.priority === 'medium' ? 'text-yellow-600' : 'text-green-600'
                          }`} />
                        )}
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{job.title}</p>
                        <p className="text-sm text-gray-600">{job.customerName}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button 
                        onClick={() => viewJobDetails(job.id)}
                        className="p-1 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                        title="View Details"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                      <button className="p-1 text-gray-600 hover:bg-gray-50 rounded transition-colors">
                        <Edit className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        job.status === 'completed' ? 'bg-green-100 text-green-800' :
                        job.status === 'in-progress' ? 'bg-blue-100 text-blue-800' :
                        job.status === 'assigned' ? 'bg-yellow-100 text-yellow-800' :
                        job.status === 'pending' ? 'bg-orange-100 text-orange-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {job.status.replace('-', ' ').toUpperCase()}
                      </span>
                      <span>{format(new Date(job.scheduledDate), 'MMM dd, yyyy')}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-bold text-gray-900">
                        ${job.totalCost.toLocaleString()}
                      </span>
                      {job.status === 'pending' && (
                        <button 
                          onClick={() => quickAssignJob(job.id)}
                          className="px-3 py-1 bg-blue-600 text-white text-xs rounded hover:bg-blue-700 transition-colors"
                        >
                          Assign
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Business Overview */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Business Overview</h2>
          </div>
          <div className="p-6">
            <div className="space-y-6">
              {/* Job Status Breakdown */}
              <div>
                <h3 className="font-medium text-gray-900 mb-3">Job Status Breakdown</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-4 h-4 bg-orange-500 rounded-full"></div>
                      <span className="text-gray-700">Pending</span>
                    </div>
                    <span className="font-semibold text-gray-900">{pendingJobs}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-4 h-4 bg-blue-500 rounded-full"></div>
                      <span className="text-gray-700">In Progress</span>
                    </div>
                    <span className="font-semibold text-gray-900">{inProgressJobs}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-4 h-4 bg-green-500 rounded-full"></div>
                      <span className="text-gray-700">Completed</span>
                    </div>
                    <span className="font-semibold text-gray-900">{completedJobs}</span>
                  </div>
                </div>
              </div>

              {/* Revenue Progress */}
              <div className="pt-6 border-t border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-600">Revenue Collected</span>
                  <span className="text-sm font-medium text-green-600">
                    ${paidRevenue.toLocaleString()} / ${totalRevenue.toLocaleString()}
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-green-500 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${(paidRevenue / totalRevenue) * 100}%` }}
                  ></div>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  {Math.round((paidRevenue / totalRevenue) * 100)}% collected
                </p>
              </div>

              {/* Quick Actions */}
              <div className="pt-6 border-t border-gray-200">
                <h3 className="font-medium text-gray-900 mb-3">Quick Actions</h3>
                <div className="grid grid-cols-2 gap-3">
                  <button 
                    onClick={() => handleQuickAction('new_job')}
                    className="flex items-center justify-center space-x-2 py-2 px-3 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 transition-colors text-sm"
                  >
                    <Plus className="h-4 w-4" />
                    <span>New Job</span>
                  </button>
                  <button 
                    onClick={() => handleQuickAction('new_invoice')}
                    className="flex items-center justify-center space-x-2 py-2 px-3 bg-green-50 text-green-700 rounded-lg hover:bg-green-100 transition-colors text-sm"
                  >
                    <FileText className="h-4 w-4" />
                    <span>New Invoice</span>
                  </button>
                  <button 
                    onClick={() => handleQuickAction('manage_team')}
                    className="flex items-center justify-center space-x-2 py-2 px-3 bg-purple-50 text-purple-700 rounded-lg hover:bg-purple-100 transition-colors text-sm"
                  >
                    <Users className="h-4 w-4" />
                    <span>Manage Team</span>
                  </button>
                  <button 
                    onClick={() => handleQuickAction('view_reports')}
                    className="flex items-center justify-center space-x-2 py-2 px-3 bg-orange-50 text-orange-700 rounded-lg hover:bg-orange-100 transition-colors text-sm"
                  >
                    <TrendingUp className="h-4 w-4" />
                    <span>View Reports</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Job Form Modal */}
      {showJobForm && (
        <JobForm
          user={user}
          job={editingJob}
          onSave={handleSaveJob}
          onCancel={() => {
            setShowJobForm(false);
            setEditingJob(undefined);
          }}
        />
      )}
    </div>
  );
};