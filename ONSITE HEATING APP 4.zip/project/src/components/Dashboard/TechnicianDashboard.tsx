import React from 'react';
import { useState } from 'react';
import { 
  Clock, 
  MapPin, 
  Wrench, 
  Calendar, 
  CheckCircle, 
  AlertTriangle,
  Plus,
  Filter,
  Download,
  Printer,
  MessageSquare,
  Navigation,
  Star,
  TrendingUp
} from 'lucide-react';
import { User, Job } from '../../types';
import { mockJobs } from '../../data/mockData';
import { format } from 'date-fns';

interface TechnicianDashboardProps {
  user: User;
}

export const TechnicianDashboard: React.FC<TechnicianDashboardProps> = ({ user }) => {
  const [jobs, setJobs] = useState(mockJobs);
  const [statusFilter, setStatusFilter] = useState('all');
  const [showNotifications, setShowNotifications] = useState(false);
  
  // Filter jobs assigned to current technician (simulated)
  const myJobs = jobs.filter(job => job.technicianId === '201' || job.technicianName);
  const todaysJobs = myJobs.filter(job => {
    const jobDate = new Date(job.scheduledDate);
    const today = new Date();
    return jobDate.toDateString() === today.toDateString();
  });

  const filteredJobs = myJobs.filter(job => {
    if (statusFilter === 'all') return true;
    return job.status === statusFilter;
  });

  const handleJobAction = (jobId: string, currentStatus: Job['status']) => {
    let newStatus: Job['status'];
    let actionMessage: string;

    switch (currentStatus) {
      case 'assigned':
        newStatus = 'in-progress';
        actionMessage = 'Job started successfully!';
        break;
      case 'in-progress':
        newStatus = 'completed';
        actionMessage = 'Job completed successfully!';
        break;
      default:
        showJobDetails(jobId);
        return;
    }

    setJobs(prev => prev.map(job => 
      job.id === jobId ? { ...job, status: newStatus, updatedAt: new Date().toISOString() } : job
    ));
    
    // Show success notification
    const notification = document.createElement('div');
    notification.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
    notification.textContent = actionMessage;
    document.body.appendChild(notification);
    setTimeout(() => document.body.removeChild(notification), 3000);
  };

  const showJobDetails = (jobId: string) => {
    const job = jobs.find(j => j.id === jobId);
    if (job) {
      alert(`Job Details:
      
Title: ${job.title}
Customer: ${job.customerName}
Phone: ${job.customerPhone}
Address: ${job.customerAddress}
Description: ${job.description}
Scheduled: ${format(new Date(job.scheduledDate), 'EEEE, MMM dd, yyyy at h:mm a')}
Duration: ${Math.round(job.estimatedDuration / 60)}h ${job.estimatedDuration % 60}m
Total Cost: $${job.totalCost.toLocaleString()}
Notes: ${job.notes || 'None'}`);
    }
  };

  const exportJobsToCSV = () => {
    const csvContent = [
      ['Job ID', 'Title', 'Customer', 'Status', 'Scheduled Date', 'Duration', 'Total Cost'].join(','),
      ...filteredJobs.map(job => [
        job.id,
        `"${job.title}"`,
        `"${job.customerName}"`,
        job.status,
        new Date(job.scheduledDate).toLocaleDateString(),
        `${Math.round(job.estimatedDuration / 60)}h ${job.estimatedDuration % 60}m`,
        job.totalCost
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `my-jobs-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);

    // Show success notification
    const notification = document.createElement('div');
    notification.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
    notification.textContent = 'Jobs exported to CSV successfully!';
    document.body.appendChild(notification);
    setTimeout(() => document.body.removeChild(notification), 3000);
  };

  const printJobList = () => {
    const printContent = `
      <html>
        <head>
          <title>My Jobs - ${new Date().toLocaleDateString()}</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            .header { text-align: center; margin-bottom: 20px; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>Onsite Heating - My Jobs</h1>
            <p>Technician: ${user.name}</p>
            <p>Generated on ${new Date().toLocaleDateString()}</p>
          </div>
          <table>
            <thead>
              <tr>
                <th>Job ID</th>
                <th>Title</th>
                <th>Customer</th>
                <th>Status</th>
                <th>Scheduled Date</th>
                <th>Duration</th>
                <th>Total Cost</th>
              </tr>
            </thead>
            <tbody>
              ${filteredJobs.map(job => `
                <tr>
                  <td>${job.id}</td>
                  <td>${job.title}</td>
                  <td>${job.customerName}</td>
                  <td>${job.status}</td>
                  <td>${new Date(job.scheduledDate).toLocaleDateString()}</td>
                  <td>${Math.round(job.estimatedDuration / 60)}h ${job.estimatedDuration % 60}m</td>
                  <td>$${job.totalCost.toLocaleString()}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const sendMessage = (customerId: string, customerName: string) => {
    const message = prompt(`Send message to ${customerName}:`);
    if (message) {
      // Show success notification
      const notification = document.createElement('div');
      notification.className = 'fixed top-4 right-4 bg-blue-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
      notification.textContent = `Message sent to ${customerName}: "${message}"`;
      document.body.appendChild(notification);
      setTimeout(() => document.body.removeChild(notification), 4000);
    }
  };

  const getDirections = (address: string) => {
    const encodedAddress = encodeURIComponent(address);
    const mapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodedAddress}`;
    window.open(mapsUrl, '_blank');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Good morning, {user.name}</h1>
            <p className="text-gray-600 mt-2">You have {todaysJobs.length} jobs scheduled for today.</p>
          </div>
          <div className="flex items-center space-x-4">
            <button 
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative p-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <MessageSquare className="h-6 w-6" />
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                3
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Notifications Panel */}
      {showNotifications && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
          <h3 className="font-semibold text-gray-900 mb-3">Recent Notifications</h3>
          <div className="space-y-2">
            <div className="flex items-center space-x-3 p-2 bg-blue-50 rounded">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <span className="text-sm">New job assigned: Emergency Heating Repair</span>
            </div>
            <div className="flex items-center space-x-3 p-2 bg-green-50 rounded">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-sm">Payment received for Job #2</span>
            </div>
            <div className="flex items-center space-x-3 p-2 bg-orange-50 rounded">
              <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
              <span className="text-sm">Schedule change requested by Sarah Johnson</span>
            </div>
          </div>
        </div>
      )}

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Today's Jobs</p>
              <p className="text-2xl font-bold text-gray-900 mt-2">{todaysJobs.length}</p>
            </div>
            <Calendar className="h-8 w-8 text-blue-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Active Jobs</p>
              <p className="text-2xl font-bold text-gray-900 mt-2">
                {myJobs.filter(job => job.status === 'in-progress').length}
              </p>
            </div>
            <Wrench className="h-8 w-8 text-orange-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Completed This Week</p>
              <p className="text-2xl font-bold text-gray-900 mt-2">
                {myJobs.filter(job => job.status === 'completed').length}
              </p>
            </div>
            <CheckCircle className="h-8 w-8 text-green-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Avg Rating</p>
              <p className="text-2xl font-bold text-gray-900 mt-2">4.8</p>
            </div>
            <Star className="h-8 w-8 text-yellow-500" />
          </div>
        </div>
      </div>

      {/* Filters and Actions */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Filter className="h-5 w-5 text-gray-400" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
            >
              <option value="all">All Jobs</option>
              <option value="assigned">Assigned</option>
              <option value="in-progress">In Progress</option>
              <option value="completed">Completed</option>
            </select>
          </div>
          <div className="flex items-center space-x-2">
            <button 
              onClick={exportJobsToCSV}
              className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
            >
              <Download className="h-4 w-4" />
              <span>Export CSV</span>
            </button>
            <button 
              onClick={printJobList}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Printer className="h-4 w-4" />
              <span>Print List</span>
            </button>
          </div>
        </div>
      </div>

      {/* Job Cards */}
      <div className="space-y-6">
        {filteredJobs.map((job) => (
          <div key={job.id} className="bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-4">
                  <div className={`p-3 rounded-full ${
                    job.priority === 'emergency' ? 'bg-red-100' :
                    job.priority === 'high' ? 'bg-orange-100' :
                    job.priority === 'medium' ? 'bg-yellow-100' : 'bg-green-100'
                  }`}>
                    {job.priority === 'emergency' ? (
                      <AlertTriangle className="h-6 w-6 text-red-600" />
                    ) : job.status === 'completed' ? (
                      <CheckCircle className="h-6 w-6 text-green-600" />
                    ) : (
                      <Wrench className={`h-6 w-6 ${
                        job.priority === 'high' ? 'text-orange-600' :
                        job.priority === 'medium' ? 'text-yellow-600' : 'text-green-600'
                      }`} />
                    )}
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900">{job.title}</h3>
                    <p className="text-gray-600 mt-1">{job.description}</p>
                    <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
                      <span className="capitalize">{job.serviceType}</span>
                      <span>•</span>
                      <span className="capitalize">{job.priority} Priority</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <span className={`px-3 py-1 text-sm font-medium rounded-full ${
                    job.status === 'completed' ? 'bg-green-100 text-green-800' :
                    job.status === 'in-progress' ? 'bg-blue-100 text-blue-800' :
                    job.status === 'assigned' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {job.status.replace('-', ' ').toUpperCase()}
                  </span>
                  <span className="text-2xl font-bold text-gray-900">
                    ${job.totalCost.toLocaleString()}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="flex items-center space-x-2 text-gray-600">
                  <Calendar className="h-4 w-4" />
                  <div>
                    <p className="text-sm font-medium">
                      {format(new Date(job.scheduledDate), 'MMM dd, yyyy')}
                    </p>
                    <p className="text-xs">
                      {format(new Date(job.scheduledDate), 'h:mm a')}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 text-gray-600">
                  <Clock className="h-4 w-4" />
                  <div>
                    <p className="text-sm font-medium">
                      {Math.round(job.estimatedDuration / 60)}h {job.estimatedDuration % 60}m
                    </p>
                    <p className="text-xs">Estimated Duration</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 text-gray-600">
                  <MapPin className="h-4 w-4" />
                  <div>
                    <p className="text-sm font-medium">{job.customerAddress.split(',')[0]}</p>
                    <p className="text-xs">{job.customerAddress.split(',').slice(1).join(',')}</p>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-900">Customer: {job.customerName}</p>
                    <p className="text-sm text-gray-600">Phone: {job.customerPhone}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button 
                      onClick={() => sendMessage(job.customerId, job.customerName)}
                      className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                      title="Send Message"
                    >
                      <MessageSquare className="h-4 w-4" />
                    </button>
                    <button 
                      onClick={() => getDirections(job.customerAddress)}
                      className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                      title="Get Directions"
                    >
                      <Navigation className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>

              {job.notes && (
                <div className="bg-blue-50 rounded-lg p-4 mb-4">
                  <p className="text-sm text-blue-800">{job.notes}</p>
                </div>
              )}

              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-500">
                  Created {format(new Date(job.createdAt), 'MMM dd, yyyy')} • 
                  Updated {format(new Date(job.updatedAt), 'MMM dd, yyyy')}
                </div>
                <div className="space-x-2">
                  <button 
                    onClick={() => showJobDetails(job.id)}
                    className="px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    View Details
                  </button>
                  <button 
                    onClick={() => handleJobAction(job.id, job.status)}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    {job.status === 'assigned' ? 'Start Job' : 
                     job.status === 'in-progress' ? 'Complete Job' : 'View Details'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredJobs.length === 0 && (
        <div className="text-center py-12">
          <Wrench className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No jobs found</h3>
          <p className="text-gray-500">Try adjusting your filter criteria.</p>
        </div>
      )}
    </div>
  );
};