import React from 'react';
import { User } from '../../types';
import { AdminDashboard } from './AdminDashboard';
import { TechnicianDashboard } from './TechnicianDashboard';
import { CustomerDashboard } from './CustomerDashboard';

interface DashboardProps {
  user: User;
}

export const Dashboard: React.FC<DashboardProps> = ({ user }) => {
  switch (user.role) {
    case 'admin':
      return <AdminDashboard user={user} />;
    case 'technician':
      return <TechnicianDashboard user={user} />;
    case 'customer':
      return <CustomerDashboard user={user} />;
    default:
      return <div>Invalid user role</div>;
  }
};