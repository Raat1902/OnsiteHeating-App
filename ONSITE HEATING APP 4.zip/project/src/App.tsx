import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './hooks/useAuth';
import { Header } from './components/Layout/Header';
import { HomePage } from './components/Home/HomePage';
import { Dashboard } from './components/Dashboard/Dashboard';
import { JobList } from './components/Jobs/JobList';
import { InvoiceList } from './components/Invoices/InvoiceList';
import { PaymentsList } from './components/Payments/PaymentsList';
import { PromotionList } from './components/Promotions/PromotionList';
import { TechnicianList } from './components/Technicians/TechnicianList';
import { EquipmentManager } from './components/Equipment/EquipmentManager';
import { ThermostatControl } from './components/Thermostat/ThermostatControl';
import { ChatBot } from './components/Chat/ChatBot';

function App() {
  const { user, login, logout, createAccount } = useAuth();

  if (!user) {
    return <HomePage onLogin={login} onCreateAccount={createAccount} />;
  }

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Header user={user} onLogout={logout} />
        <main>
          <Routes>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard" element={<Dashboard user={user} />} />
            <Route path="/jobs" element={<JobList user={user} />} />
            {user.role !== 'customer' && (
              <Route path="/invoices" element={<InvoiceList user={user} />} />
            )}
            {user.role === 'admin' && (
              <Route path="/promotions" element={<PromotionList user={user} />} />
            )}
            {user.role !== 'customer' && (
              <Route path="/technicians" element={<TechnicianList user={user} />} />
            )}
            {user.role === 'customer' && (
              <Route path="/payments" element={<PaymentsList user={user} />} />
            )}
            {user.role === 'customer' && (
              <Route path="/equipment" element={<EquipmentManager customer={user} />} />
            )}
            <Route path="/thermostat" element={<ThermostatControl customerId={user.id} />} />
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </main>
        <ChatBot />
      </div>
    </Router>
  );
}

export default App;