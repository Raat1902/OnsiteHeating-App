export interface User {
  id: string;
  name: string;
  email: string;
  role: 'customer' | 'technician' | 'admin';
  phone?: string;
  address?: string;
  avatar?: string;
  createdAt?: string;
}

export interface Job {
  id: string;
  customerId: string;
  customerName: string;
  customerAddress: string;
  customerPhone: string;
  technicianId?: string;
  technicianName?: string;
  title: string;
  description: string;
  serviceType: 'installation' | 'repair' | 'maintenance' | 'emergency';
  status: 'pending' | 'assigned' | 'in-progress' | 'completed' | 'cancelled';
  priority: 'low' | 'medium' | 'high' | 'emergency';
  scheduledDate: string;
  estimatedDuration: number;
  laborCost: number;
  materialCost: number;
  totalCost: number;
  createdAt: string;
  updatedAt: string;
  notes?: string;
}

export interface Invoice {
  id: string;
  jobId: string;
  customerId: string;
  customerName: string;
  amount: number;
  status: 'draft' | 'sent' | 'paid' | 'overdue';
  dueDate: string;
  createdAt: string;
  items: InvoiceItem[];
}

export interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  rate: number;
  amount: number;
}

export interface Payment {
  id: string;
  invoiceId: string;
  amount: number;
  method: 'cash' | 'check' | 'card' | 'bank_transfer';
  status: 'pending' | 'completed' | 'failed';
  processedAt: string;
}

export interface Promotion {
  id: string;
  title: string;
  description: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  validFrom: string;
  validTo: string;
  serviceTypes: string[];
  isActive: boolean;
  maxUses?: number;
  currentUses: number;
  code?: string;
}

export interface Technician {
  id: string;
  name: string;
  email: string;
  phone: string;
  specialties: string[];
  rating: number;
  completedJobs: number;
  isAvailable: boolean;
  currentLocation?: {
    lat: number;
    lng: number;
    address: string;
  };
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  preferredTechnician?: string;
  serviceHistory: string[];
  totalSpent: number;
  loyaltyPoints: number;
  thermostatSettings?: ThermostatSettings;
  zones?: Zone[];
  equipment?: Equipment[];
}

export interface Equipment {
  id: string;
  customerId: string;
  type: 'furnace' | 'ac_unit' | 'water_heater' | 'heat_pump' | 'ductwork' | 'thermostat';
  brand: string;
  model: string;
  serialNumber: string;
  installDate: string;
  warrantyExpiry: string;
  lastServiceDate?: string;
  nextServiceDue?: string;
  specifications: EquipmentSpec[];
  manuals?: string[];
  photos?: string[];
  status: 'active' | 'needs_service' | 'warranty_expired' | 'replaced';
}

export interface EquipmentSpec {
  name: string;
  value: string;
  unit?: string;
  category: 'performance' | 'dimensions' | 'electrical' | 'efficiency' | 'capacity';
}

export interface ThermostatSettings {
  id: string;
  customerId: string;
  currentTemp: number;
  targetTemp: number;
  mode: 'heat' | 'cool' | 'auto' | 'off';
  schedule: Schedule[];
  awayMode: boolean;
  geofencing: boolean;
  location?: {
    lat: number;
    lng: number;
  };
  energyUsage: EnergyData[];
  alerts: Alert[];
  airQuality: AirQualityData;
  humidity: HumidityData;
  occupancy: OccupancyData[];
}

export interface Schedule {
  id: string;
  dayOfWeek: number; // 0-6 (Sunday-Saturday)
  startTime: string; // "06:00"
  endTime: string; // "09:00"
  targetTemp: number;
  isActive: boolean;
}

export interface Zone {
  id: string;
  name: string;
  currentTemp: number;
  targetTemp: number;
  humidity: number;
  isActive: boolean;
  sensorId: string;
  airQuality?: AirQualityData;
  occupancy?: boolean;
  lastSeen?: string;
}

export interface EnergyData {
  timestamp: string;
  temperature: number;
  targetTemp: number;
  heatingOn: boolean;
  energyUsed: number; // kWh
  cost: number; // dollars
}

export interface Alert {
  id: string;
  type: 'temperature' | 'energy' | 'maintenance' | 'system' | 'air_quality' | 'occupancy';
  message: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  timestamp: string;
  isRead: boolean;
}

export interface WeatherData {
  temperature: number;
  humidity: number;
  condition: string;
  forecast: {
    high: number;
    low: number;
    condition: string;
  }[];
}

export interface AirQualityData {
  co2: number; // ppm
  voc: number; // ppb
  pm25: number; // μg/m³
  aqi: number; // Air Quality Index 0-500
  lastUpdated: string;
}

export interface HumidityData {
  current: number; // %
  target: number; // %
  humidifierOn: boolean;
  dehumidifierOn: boolean;
  ventilationOn: boolean;
}

export interface OccupancyData {
  zoneId: string;
  occupied: boolean;
  lastSeen: string;
  motionDetected: boolean;
}

export interface ChatMessage {
  id: string;
  message: string;
  sender: 'user' | 'bot';
  timestamp: string;
  type?: 'text' | 'action' | 'booking';
  actions?: ChatAction[];
}

export interface ChatAction {
  id: string;
  label: string;
  action: string;
  data?: any;
}

export interface AIRecommendation {
  id: string;
  type: 'energy_saving' | 'schedule_optimization' | 'maintenance' | 'anomaly';
  title: string;
  description: string;
  impact: string;
  confidence: number;
  createdAt: string;
}