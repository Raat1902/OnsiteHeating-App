import { useState } from 'react';
import { Job, User, Promotion } from '../types';

export const useBooking = () => {
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [selectedPromotion, setSelectedPromotion] = useState<Promotion | null>(null);
  const [bookingStep, setBookingStep] = useState<'service' | 'details' | 'confirmation'>('service');

  const openBookingModal = (promotion?: Promotion) => {
    setSelectedPromotion(promotion || null);
    setIsBookingModalOpen(true);
    setBookingStep('service');
  };

  const closeBookingModal = () => {
    setIsBookingModalOpen(false);
    setSelectedPromotion(null);
    setBookingStep('service');
  };

  const nextStep = () => {
    if (bookingStep === 'service') setBookingStep('details');
    else if (bookingStep === 'details') setBookingStep('confirmation');
  };

  const prevStep = () => {
    if (bookingStep === 'details') setBookingStep('service');
    else if (bookingStep === 'confirmation') setBookingStep('details');
  };

  return {
    isBookingModalOpen,
    selectedPromotion,
    bookingStep,
    openBookingModal,
    closeBookingModal,
    nextStep,
    prevStep
  };
};