import { useState } from 'react';
import { User } from '../types';

export const useAuth = () => {
  const [user, setUser] = useState<User | null>(null);

  const login = (email: string, password: string, role: User['role']) => {
    // Admin accounts for Javid and Rania Atmani
    if (email === 'javid@onsiteheating.com' && role === 'admin') {
      setUser({
        id: 'admin-1',
        name: 'Javid Atmani',
        email: 'javid@onsiteheating.com',
        role: 'admin',
        phone: '(555) 123-4567',
        address: '123 Business St, Springfield, IL 62701',
        avatar: 'JA',
        createdAt: '2024-01-01T00:00:00Z'
      });
      return;
    }
    
    if (email === 'rania@onsiteheating.com' && role === 'admin') {
      setUser({
        id: 'admin-2',
        name: 'Rania Atmani',
        email: 'rania@onsiteheating.com',
        role: 'admin',
        phone: '(555) 123-4568',
        address: '123 Business St, Springfield, IL 62701',
        avatar: 'RA',
        createdAt: '2024-01-01T00:00:00Z'
      });
      return;
    }

    // Simulate login for other users
    setUser({
      id: role === 'customer' ? 'cust-1' : role === 'technician' ? 'tech-1' : 'admin-3',
      name: role === 'customer' ? 'Jane Smith' : role === 'technician' ? 'Mike Johnson' : 'Admin User',
      email,
      role,
      phone: '(555) 123-4567',
      address: '123 Main St, City, State 12345',
      avatar: role === 'customer' ? 'JS' : role === 'technician' ? 'MJ' : 'AU',
      createdAt: new Date().toISOString()
    });
  };

  const logout = () => {
    setUser(null);
  };

  const createAccount = (userData: Partial<User>) => {
    const newUser: User = {
      id: `user-${Date.now()}`,
      name: userData.name || '',
      email: userData.email || '',
      role: userData.role || 'customer',
      phone: userData.phone,
      address: userData.address,
      avatar: userData.name?.split(' ').map(n => n[0]).join('') || 'U',
      createdAt: new Date().toISOString()
    };
    
    setUser(newUser);
    return newUser;
  };

  return { user, login, logout, createAccount };
};