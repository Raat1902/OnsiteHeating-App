import { Job, Invoice, Payment } from '../types';
import { Promotion, Technician, Customer } from '../types';

export const mockJobs: Job[] = [
  {
    id: '1',
    customerId: '101',
    customerName: 'Sarah Johnson',
    customerAddress: '456 Oak Ave, Springfield, IL 62701',
    customerPhone: '(555) 234-5678',
    technicianId: '201',
    technicianName: 'Mike Rodriguez',
    title: 'Furnace Installation',
    description: 'Install new high-efficiency gas furnace in basement',
    serviceType: 'installation',
    status: 'in-progress',
    priority: 'high',
    scheduledDate: '2025-01-20T09:00:00Z',
    estimatedDuration: 480,
    laborCost: 800,
    materialCost: 2400,
    totalCost: 3200,
    createdAt: '2025-01-15T10:30:00Z',
    updatedAt: '2025-01-18T14:20:00Z',
    notes: 'Customer requested premium model with 10-year warranty'
  },
  {
    id: '2',
    customerId: '102',
    customerName: 'Robert Chen',
    customerAddress: '789 Pine St, Springfield, IL 62702',
    customerPhone: '(555) 345-6789',
    technicianId: '202',
    technicianName: 'Lisa Thompson',
    title: 'AC Repair',
    description: 'Refrigerant leak repair and system recharge',
    serviceType: 'repair',
    status: 'completed',
    priority: 'medium',
    scheduledDate: '2025-01-18T13:00:00Z',
    estimatedDuration: 120,
    laborCost: 150,
    materialCost: 89,
    totalCost: 239,
    createdAt: '2025-01-17T09:15:00Z',
    updatedAt: '2025-01-18T15:45:00Z'
  },
  {
    id: '3',
    customerId: '103',
    customerName: 'Emily Davis',
    customerAddress: '321 Elm Dr, Springfield, IL 62703',
    customerPhone: '(555) 456-7890',
    title: 'Emergency Heating Repair',
    description: 'No heat - furnace not starting',
    serviceType: 'emergency',
    status: 'pending',
    priority: 'emergency',
    scheduledDate: '2025-01-20T16:00:00Z',
    estimatedDuration: 180,
    laborCost: 200,
    materialCost: 150,
    totalCost: 350,
    createdAt: '2025-01-20T08:30:00Z',
    updatedAt: '2025-01-20T08:30:00Z',
    notes: 'Customer has elderly residents - priority service'
  },
  {
    id: '4',
    customerId: '104',
    customerName: 'David Wilson',
    customerAddress: '654 Maple Ln, Springfield, IL 62704',
    customerPhone: '(555) 567-8901',
    technicianId: '201',
    technicianName: 'Mike Rodriguez',
    title: 'Annual Maintenance',
    description: 'Routine HVAC system inspection and tune-up',
    serviceType: 'maintenance',
    status: 'assigned',
    priority: 'low',
    scheduledDate: '2025-01-22T10:00:00Z',
    estimatedDuration: 90,
    laborCost: 120,
    materialCost: 35,
    totalCost: 155,
    createdAt: '2025-01-19T11:00:00Z',
    updatedAt: '2025-01-19T16:30:00Z'
  }
];

export const mockInvoices: Invoice[] = [
  {
    id: 'INV-001',
    jobId: '2',
    customerId: '102',
    customerName: 'Robert Chen',
    amount: 239,
    status: 'paid',
    dueDate: '2025-02-01T00:00:00Z',
    createdAt: '2025-01-18T16:00:00Z',
    items: [
      {
        id: '1',
        description: 'Refrigerant leak repair',
        quantity: 1,
        rate: 150,
        amount: 150
      },
      {
        id: '2',
        description: 'R-410A Refrigerant (2 lbs)',
        quantity: 2,
        rate: 44.50,
        amount: 89
      }
    ]
  },
  {
    id: 'INV-002',
    jobId: '1',
    customerId: '101',
    customerName: 'Sarah Johnson',
    amount: 3200,
    status: 'sent',
    dueDate: '2025-02-15T00:00:00Z',
    createdAt: '2025-01-20T17:30:00Z',
    items: [
      {
        id: '3',
        description: 'Furnace installation labor',
        quantity: 8,
        rate: 100,
        amount: 800
      },
      {
        id: '4',
        description: 'High-efficiency gas furnace',
        quantity: 1,
        rate: 2400,
        amount: 2400
      }
    ]
  }
];

export const mockPayments: Payment[] = [
  {
    id: 'PAY-001',
    invoiceId: 'INV-001',
    amount: 239,
    method: 'card',
    status: 'completed',
    processedAt: '2025-01-19T10:15:00Z'
  }
];

export const mockPromotions: Promotion[] = [
  {
    id: 'PROMO-001',
    title: 'Winter Heating Special',
    description: '20% off all heating system installations and repairs',
    discountType: 'percentage',
    discountValue: 20,
    validFrom: '2025-01-01T00:00:00Z',
    validTo: '2025-03-31T23:59:59Z',
    serviceTypes: ['installation', 'repair'],
    isActive: true,
    maxUses: 100,
    currentUses: 23,
    code: 'WINTER20'
  },
  {
    id: 'PROMO-002',
    title: 'New Customer Discount',
    description: '$50 off your first service call',
    discountType: 'fixed',
    discountValue: 50,
    validFrom: '2025-01-01T00:00:00Z',
    validTo: '2025-12-31T23:59:59Z',
    serviceTypes: ['installation', 'repair', 'maintenance'],
    isActive: true,
    currentUses: 45,
    code: 'NEWCUSTOMER50'
  },
  {
    id: 'PROMO-003',
    title: 'Annual Maintenance Package',
    description: '15% off when you book annual maintenance',
    discountType: 'percentage',
    discountValue: 15,
    validFrom: '2025-01-01T00:00:00Z',
    validTo: '2025-12-31T23:59:59Z',
    serviceTypes: ['maintenance'],
    isActive: true,
    currentUses: 12
  }
];

export const mockTechnicians: Technician[] = [
  {
    id: '201',
    name: 'Mike Rodriguez',
    email: 'mike@onsiteheating.com',
    phone: '(555) 123-4567',
    specialties: ['Installation', 'Gas Systems', 'Emergency Repair'],
    rating: 4.8,
    completedJobs: 156,
    isAvailable: true,
    currentLocation: {
      lat: 39.7817,
      lng: -89.6501,
      address: 'Downtown Springfield, IL'
    }
  },
  {
    id: '202',
    name: 'Lisa Thompson',
    email: 'lisa@onsiteheating.com',
    phone: '(555) 234-5678',
    specialties: ['AC Repair', 'Maintenance', 'Ductwork'],
    rating: 4.9,
    completedJobs: 203,
    isAvailable: false,
    currentLocation: {
      lat: 39.7990,
      lng: -89.6441,
      address: 'North Springfield, IL'
    }
  },
  {
    id: '203',
    name: 'David Chen',
    email: 'david@onsiteheating.com',
    phone: '(555) 345-6789',
    specialties: ['Heat Pumps', 'Smart Thermostats', 'Energy Efficiency'],
    rating: 4.7,
    completedJobs: 89,
    isAvailable: true
  }
];

export const mockCustomers: Customer[] = [
  {
    id: '101',
    name: 'Sarah Johnson',
    email: 'sarah@email.com',
    phone: '(555) 234-5678',
    address: '456 Oak Ave, Springfield, IL 62701',
    preferredTechnician: '201',
    serviceHistory: ['1', '4'],
    totalSpent: 3355,
    loyaltyPoints: 335,
    equipment: [
      {
        id: 'eq-1',
        customerId: '101',
        type: 'furnace',
        brand: 'Carrier',
        model: 'Performance 96 59TP6',
        serialNumber: 'CR2024001234',
        installDate: '2022-10-15T00:00:00Z',
        warrantyExpiry: '2032-10-15T00:00:00Z',
        lastServiceDate: '2024-09-15T00:00:00Z',
        nextServiceDue: '2025-09-15T00:00:00Z',
        status: 'active',
        specifications: [
          { name: 'AFUE Rating', value: '96', unit: '%', category: 'efficiency' },
          { name: 'BTU Input', value: '80,000', unit: 'BTU/h', category: 'capacity' },
          { name: 'BTU Output', value: '76,800', unit: 'BTU/h', category: 'capacity' },
          { name: 'Dimensions', value: '33" W x 29" D x 58" H', category: 'dimensions' },
          { name: 'Weight', value: '180', unit: 'lbs', category: 'dimensions' },
          { name: 'Electrical', value: '115V/60Hz/1Ph', category: 'electrical' },
          { name: 'Gas Connection', value: '1/2" NPT', category: 'performance' }
        ],
        manuals: ['Carrier_59TP6_Installation_Manual.pdf', 'Carrier_59TP6_User_Guide.pdf']
      },
      {
        id: 'eq-2',
        customerId: '101',
        type: 'ac_unit',
        brand: 'Carrier',
        model: 'Comfort 13 24ACC3',
        serialNumber: 'CR2023005678',
        installDate: '2023-05-20T00:00:00Z',
        warrantyExpiry: '2033-05-20T00:00:00Z',
        status: 'active',
        specifications: [
          { name: 'SEER Rating', value: '13', category: 'efficiency' },
          { name: 'Cooling Capacity', value: '24,000', unit: 'BTU/h', category: 'capacity' },
          { name: 'Refrigerant Type', value: 'R-410A', category: 'performance' },
          { name: 'Compressor Type', value: 'Single Stage', category: 'performance' },
          { name: 'Sound Level', value: '76', unit: 'dB', category: 'performance' },
          { name: 'Dimensions', value: '29" W x 29" D x 35" H', category: 'dimensions' },
          { name: 'Weight', value: '125', unit: 'lbs', category: 'dimensions' }
        ]
      }
    ]
  },
  {
    id: '102',
    name: 'Robert Chen',
    email: 'robert@email.com',
    phone: '(555) 345-6789',
    address: '789 Pine St, Springfield, IL 62702',
    serviceHistory: ['2'],
    totalSpent: 239,
    loyaltyPoints: 24
  },
  {
    id: '103',
    name: 'Emily Davis',
    email: 'emily@email.com',
    phone: '(555) 456-7890',
    address: '321 Elm Dr, Springfield, IL 62703',
    serviceHistory: ['3'],
    totalSpent: 0,
    loyaltyPoints: 0
  },
  {
    id: '104',
    name: 'David Wilson',
    email: 'david@email.com',
    phone: '(555) 567-8901',
    address: '654 Maple Ln, Springfield, IL 62704',
    serviceHistory: ['4'],
    totalSpent: 155,
    loyaltyPoints: 15
  }
];

export const mockThermostatData = {
  id: 'thermo-101',
  customerId: '101',
  currentTemp: 21.5,
  targetTemp: 22,
  mode: 'heat' as const,
  schedule: [
    {
      id: 'sched-1',
      dayOfWeek: 1, // Monday
      startTime: '06:00',
      endTime: '09:00',
      targetTemp: 22,
      isActive: true
    },
    {
      id: 'sched-2',
      dayOfWeek: 1,
      startTime: '17:00',
      endTime: '22:00',
      targetTemp: 21,
      isActive: true
    }
  ],
  awayMode: false,
  geofencing: true,
  location: {
    lat: 39.7817,
    lng: -89.6501
  },
  energyUsage: [
    {
      timestamp: '2025-01-20T08:00:00Z',
      temperature: 20.5,
      targetTemp: 22,
      heatingOn: true,
      energyUsed: 2.3,
      cost: 0.28
    },
    {
      timestamp: '2025-01-20T09:00:00Z',
      temperature: 21.8,
      targetTemp: 22,
      heatingOn: false,
      energyUsed: 0,
      cost: 0
    }
  ],
  alerts: [
    {
      id: 'alert-1',
      type: 'temperature' as const,
      message: 'Temperature dropped below 18°C in living room',
      severity: 'medium' as const,
      timestamp: '2025-01-20T06:30:00Z',
      isRead: false
    }
  ]
};

export const mockWeatherData = {
  temperature: 5,
  humidity: 65,
  condition: 'Partly Cloudy',
  forecast: [
    { high: 8, low: 2, condition: 'Snow' },
    { high: 12, low: 4, condition: 'Cloudy' },
    { high: 15, low: 7, condition: 'Sunny' }
  ]
};